# Uds Plus Observation Lab Result Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Observation Lab Result Example**

## Example Observation: Uds Plus Observation Lab Result Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-lab-observation"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentified-instant-extension",
    "valueDateTime" : "2005"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory",
      "display" : "Laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "718-7",
      "display" : "Hemoglobin [Mass/volume] in Blood"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "encounter" : {
    "reference" : "Encounter/de-identified-example"
  },
  "effectiveDateTime" : "2005",
  "performer" : [{
    "reference" : "Practitioner/example"
  }],
  "valueQuantity" : {
    "value" : 17,
    "unit" : "g/dL",
    "system" : "http://unitsofmeasure.org"
  },
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "368208006",
      "display" : "Left upper arm structure"
    }]
  }
}

```
