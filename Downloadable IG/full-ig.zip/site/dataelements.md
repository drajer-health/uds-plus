# Data Elements and FHIR Mappings - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* **Data Elements and FHIR Mappings**

## Data Elements and FHIR Mappings

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

This section provides an overview of the UDS+ data elements and their mappings to US Core and QI Core and other IGs as needed.

### UDS+ Data Elements

The UDS+ data elements have been identified in the UDS Reporting Manuals. For the UDS+ project, the following data elements identified in the below UDS tables will be considered for reporting.

* Elements in the Zip Code Data Table
* Table 3A: Patients by Age and by Sex Assigned at Birth
* Table 3B: Demographic Characteristics
* Table 4: Selected Patient Characteristics
* Table 6A: Selected Diagnoses and Services Rendered
* Table 6B: Quality of Care Measures
* Table 7: Health Outcomes and Disparities

### Analysis of the Zip Code Data Table, Table 3A, Table 3B, Table 4 and Table 6A

The data elements from the above tables have been analyzed to understand the additional data elements that would be needed to be supported by certified EHR technologies as part of the FHIR APIs. This analysis is presented in the table below which identifies the UDS data element, the profiles to be used for UDS+ reporting and the differences between US Core/USCDIv2 and UDS+.

| | | |
| :--- | :--- | :--- |
| UDS Data Element | UDS+ Reporting FHIR Profile Mapping | Differences with US Core - 9.0.0 (USCDIv5) |
| UDS Table : Patients By Zip Code Table | | |
| Zip Code | uds-plus-deidentified-patient.address.postalCode | None |
| Insurance Type | uds-plus-coverage.type | Value Set specific to UDS+ reporting |
| UDS Table 3A: Patients By Age and By Sex Assigned at Birth | | |
| Age | uds-plus-deidentified-patient.extension (dapl-age-extension) | Populated using the birthDate of the patient as of December 31st for the reporting year. |
| Sex | uds-plus-deidentified-patient.extension (dapl-sex-extension) | None |
| UDS Table 3B: Demographic Characteristics | | |
| Race | uds-plus-deidentified-patient.extension (us-core-race-extension) | Require both ombCategory and Detailed Race codes for UDS+ reporting |
| Ethnicity | uds-plus-deidentified-patient.extension (us-core-ethnicity) | Require both ombCategory and Detailed Ethnicity codes for UDS+ reporting |
| Preferred Language | uds-plus-deidentified-patient.communication.language | None |
| UDS Table 4: Selected Patient Characteristics | | |
| Income | dapl-deidentified-income-observation.code & dapl-deidentified-income-observation.valueRange | Income is modeled as an observation and is not present in US Core. |
| Insurance | uds-plus-coverage.type | Value Set specific to UDS+ reporting |
| Special Population - Migratory/Seasonal worker | uds-plus-patient.extension (uds-plus-plus-agriculture-worker-status) | Extension added for UDS+ reporting as it is not present in US Core |
| Special Population - Homeless | uds-plus-patient.extension (uds-plus-plus-housing-status) | Extension added for UDS+ reporting as it is not present in US Core |
| Special Population - Veterans | uds-plus-patient.extension (uds-plus-plus-veteran-status) | Extension added for UDS+ reporting as it is not present in US Core |
| Total School-based Service Site Patients | uds-plus-encounter.location.location.type | Updated value set to include UDS+ codes |
| Total Residents of Public Housing | uds-plus-encounter.location.location.type | Updated value set to include UDS+ codes |
| UDS Table 6A: Selected Diagnoses and Services Rendered | | |
| Diagnosis | dapl-diagnosis.code | None |
| Diagnosis Date | dapl-diagnosis.assertedDate | None |
| Encounter Date | uds-plus-encounter.period | None |
| Patient Visit | uds-plus-encounter.subject, dapl-diagnosis.subject, dapl-diagnosis.code & uds-plus-encounter.code & uds-plus-encounter.reasonCode | None |
| Procedure | dapl-procedure.code | None |
| Procedure Date | dapl-procedure.performedDate | None |
| Procedure Patient | dapl-procedure.subject | None |
| Tests/Orders Patient | dapl-servicerequest.subject | None |
| Tests/Orders code | dapl-servicerequest.code | None |
| Immunizations | dapl-immunization.vaccineCode | None |
| Immunizations Patient | dapl-immunization.patient | None |

### Analysis of the Table 6B and 7 (Quality of Care Measures and Health Outcomes and Disparities

UDS+ reports require data to be reported for Quality of Care Measures and also for Health Outcomes and Disparities measures. In order to compute the various populations that fall into the patient population, numerators, denominators, exclusions for the measures the required data elements were identified from the Quality Measure eCQM definitions. These data elements are based of the QDM data elements. These QDM data elements are then mapped to QI Core or UDS+ profiles for reporting purposes. In addition analysis was performed to identify the delta between US Core/USCDIv2 and the data elements required for the computation of the quality measures. This analysis will aid in the decision making on how to best align the ONC USCDI+ data elements to Federal Agency requirements in future versions of USCDI and USCDI+.

The analysis is presented in the table below.

* **Deliveries and Birth Weight Data**: UDS Data Element
  * ?: FHIR Profile Mapping
  * ?: Differences with US Core 6.1.0
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Immunization, Administered - Status
  * ?: dapl-immunization.status
  * ?: None
* **Deliveries and Birth Weight Data**: Immunization, Administered - Vaccination Code
  * ?: dapl-immunization.vaccineCode
  * ?: None
* **Deliveries and Birth Weight Data**: Immunization, Administered - Occurrence DateTime
  * ?: dapl-immunization.occurrenceDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Age
  * ?: uds-plus-patient.extension.dapl-age-extension, uds-plus-encounter.extension.dapl-age-extnesion
  * ?: Computed from Patient.birthDate and if required visit date
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - Sex
  * ?: uds-plus-patient.extension (uds-plus-sex-extension)
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Device, Order - Code
  * ?: dapl-servicerequest.code
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Device, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnoses - Condition
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Present On Admission
  * ?: uds-plus-encounter.diagnosis.use
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - Code
  * ?: dapl-clinical-result-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - DateTime/Period
  * ?: dapl-clinical-result-observation.effectiveDateTime OR dapl-clinical-result-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - Issued
  * ?: dapl-clinical-result-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic - Sex
  * ?: uds-plus-patient.extension (uds-plus-sex-extension)
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Symptom - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Onset DateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Abatement DateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Order - Code
  * ?: dapl-medicationrequest.medicationCodeableConcept
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - Timing
  * ?: dapl-medicationrequest.dosageInstruction.timing
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - AuthoredOn
  * ?: dapl-medicationrequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Order - Code
  * ?: dapl-medicationrequest.medicationCodeableConcept
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - Timing
  * ?: dapl-medicationrequest.dosageInstruction.timing
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - AuthoredOn
  * ?: dapl-medicationrequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Adverse Event - Event
  * ?: dapl-adverseevent.event
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Adverse Event - Date
  * ?: dapl-adverseevent.date
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Adverse Event - Recorded
  * ?: dapl-adverseevent.recordedDate
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Allergy Intolerance - Code
  * ?: dapl-allergyintolerance.code, dapl-allergyintolerance.type
  * ?: None
* **Deliveries and Birth Weight Data**: Allergy Intolerance - Onset
  * ?: dapl-allergyintolerance.onsetPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Allergy Intolerance - Recorded
  * ?: dapl-allergyintolerance.recordedDate
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Order - Code
  * ?: dapl-medicationrequest.medicationCodeableConcept
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - Timing
  * ?: dapl-medicationrequest.dosageInstruction.timing
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - AuthoredOn
  * ?: dapl-medicationrequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Device, Order- Code
  * ?: dapl-servicerequest.code
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Device, Order- AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnoses - Condition
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Present On Admission
  * ?: uds-plus-encounter.diagnosis.use
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - Code
  * ?: dapl-clinical-result-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - DateTime/Period
  * ?: dapl-clinical-result-observation.effectiveDateTime OR dapl-clinical-result-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnostic Study, Performed - Issued
  * ?: dapl-clinical-result-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Result - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Value
  * ?: dapl-observation.value[x] (valueQuantity/valueCodeableConcept/valueDateTime)
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Onset DateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Abatement DateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Order - Code
  * ?: dapl-medicationrequest.medicationCodeableConcept
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - Timing
  * ?: dapl-medicationrequest.dosageInstruction.timing
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Order - AuthoredOn
  * ?: dapl-medicationrequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic - Birth Date
  * ?: uds-plus-patient.extension (age)
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic - Expired
  * ?: uds-plus-patient.deceasedBoolean
  * ?: None
* **Deliveries and Birth Weight Data**: None
  * ?: None
  * ?: None
* **Deliveries and Birth Weight Data**: None
  * ?: None
  * ?: None
* **Deliveries and Birth Weight Data**: None
  * ?: None
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic - Birth Date
  * ?: uds-plus-patient.extension (age)
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Performed
  * ?: uds-plus-encounter
  * ?: None
* **Deliveries and Birth Weight Data**: Discharge Disposition
  * ?: uds-plus-encounter.dischargeDisposition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Diagnosis
  * ?: dapl-condition.code and dapl-condition.category
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis Time (OnsetTime)
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure Performed
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure Performed DateTime
  * ?: dapl-procedure.performedDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Intervention Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention(Performed) - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention(Performed) - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention(Performed) - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Encounter Performed
  * ?: uds-plus-encounter
  * ?: None
* **Deliveries and Birth Weight Data**: Discharge Disposition
  * ?: uds-plus-encounter.dischargeDisposition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Diagnosis
  * ?: dapl-condition.code and dapl-condition.category
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis Time (OnsetTime)
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Value
  * ?: dapl-observation.value[x] (valueQuantity/valueCodeableConcept/valueDateTime)
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention Order - Referral
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic - Birth Date
  * ?: uds-plus-patient.extension (age)
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Performed
  * ?: uds-plus-encounter
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Type
  * ?: uds-plus-encounter.type
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter Diagnosis
  * ?: dapl-condition.code and dapl-condition.category
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis Time (OnsetTime)
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure Performed
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure Performed DateTime
  * ?: dapl-procedure.performedDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure(Performed) - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Device, Order - Code
  * ?: dapl-servicerequest.code
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Device, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnoses - Condition
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Present On Admission
  * ?: uds-plus-encounter.diagnosis.use
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Author DateTime
  * ?: 
  * ?: Missing in US Core & QI Core profiles
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Physical Exam, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Procedure, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Result - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Value
  * ?: dapl-observation.value[x] (valueQuantity/valueCodeableConcept/valueDateTime)
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Onset DateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Abatement DateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Result
  * ?: dapl-observation.value[x]
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Assessment, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Device, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Device, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnoses - Condition Present On Admission
  * ?: uds-plus-encounter.diagnosis.use
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Diagnosis - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - OnsetDateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - AbatementDateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Diagnosis - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Participant
  * ?: uds-plus-encounter.participant.individual
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis
  * ?: uds-plus-encounter.diagnosis.condition
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Diagnosis Rank
  * ?: uds-plus-encounter.diagnosis.rank
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Period
  * ?: uds-plus-encounter.period
  * ?: None
* **Deliveries and Birth Weight Data**: Encounter, Performed - Author DateTime
  * ?: 
  * ?: Missing in US Core & QI Core profiles
* **Deliveries and Birth Weight Data**: Intervention, Order - Code
  * ?: dapl-servicerequest.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Order - AuthoredOn
  * ?: dapl-servicerequest.authoredOn
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Code
  * ?: dapl-procedure.code
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - DateTime/Period
  * ?: dapl-procedure.performedDateTime OR dapl-procedure.performedPeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Intervention, Performed - Recorded
  * ?: dapl-procedure.extension(dapl-recordedDate extension)
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - DateTime/Period
  * ?: dapl-observation.effectiveDateTime OR dapl-observation.effectivePeriod
  * ?: None
* **Deliveries and Birth Weight Data**: Laboratory Test, Performed - Issued
  * ?: dapl-observation.issued
  * ?: None
* **Deliveries and Birth Weight Data**: Medication, Active - Status
  * ?: dapl-medicationstatement.status OR dapl-medicationrequest.status
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - Code
  * ?: dapl-medicationstatement.medicationCodeableConcept OR dapl-medicationrequest.medicationCodeableConcept
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Medication, Active - DateTime/Period
  * ?: dapl-medicationstatement.effectiveDateTime OR dapl-medicationstatement.effectivePeriod OR dapl-medicationrequest.dosageInstruction.timing
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Payer
  * ?: uds-plus-coverage.payor
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Payer - Period
  * ?: uds-plus-coverage.period
  * ?: Missing in US Core profile
* **Deliveries and Birth Weight Data**: Patient Characteristic, Ethnicity - Ethnicity
  * ?: uds-plus-patient.extension.us-core-ethnicity
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Race - Race
  * ?: uds-plus-patient.extension.us-core-race
  * ?: None
* **Deliveries and Birth Weight Data**: Patient Characteristic, Sex - ONC Administrative Sex
  * ?: uds-plus-patient.gender
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Code
  * ?: dapl-observation.code
  * ?: None
* **Deliveries and Birth Weight Data**: Result - Value
  * ?: dapl-observation.value[x] (valueQuantity/valueCodeableConcept/valueDateTime)
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Code
  * ?: dapl-condition.code
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Onset DateTime
  * ?: dapl-condition.onsetDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - Abatement DateTime
  * ?: dapl-condition.abatementDateTime
  * ?: None
* **Deliveries and Birth Weight Data**: Symptom - ClinicalStatus
  * ?: dapl-condition.clinicalStatus
  * ?: None
* **Deliveries and Birth Weight Data**: Prenatal Patient Services by Delivery
  * ?: UDS Manifest.hcPrenatalCareByReferralOnly
  * ?: None
* **Deliveries and Birth Weight Data**: First Trimester, Second Trimester, Third Trimester
  * ?: dapl-diagnosis.code & uds-plus-encounter.code & uds-plus-encounter.reasonCode
  * ?: None
* **Deliveries and Birth Weight Data**: HIV Positive Pregnant Patients
  * ?: dapl-diagnosis.code
  * ?: None
* **Deliveries and Birth Weight Data**: Deliveries Performed by Health Center Providers
  * ?: dapl-diagnosis.code & uds-plus-encounter.code & uds-plus-encounter.reasonCode
  * ?: None
* **Deliveries and Birth Weight Data**: Prenatal Care Patients who delivered during the year
  * ?: dapl-diagnosis.code & uds-plus-encounter.code & uds-plus-encounter.reasonCode
  * ?: None
* **Deliveries and Birth Weight Data**: Live Birth Weight
  * ?: dapl-observation.code & dapl-observation.value[x], Use LOINC code of 8339-4 for capturing the weight.
  * ?: None

