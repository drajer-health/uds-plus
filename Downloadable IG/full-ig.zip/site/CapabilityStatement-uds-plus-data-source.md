# Uds Plus Data Source CapabilityStatement - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Data Source CapabilityStatement**

## CapabilityStatement: Uds Plus Data Source CapabilityStatement 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-source | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusDataSource |

 
This is a CapabilityStatement that defines the expected capabilities of the Data Source actor. 

 [Raw OpenAPI-Swagger Definition file](uds-plus-data-source.openapi.json) | [Download](uds-plus-data-source.openapi.json) 

## Data Source (e.g, EHR)

(Requirements Definition Capability Statement)

Canonical URL: http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-source

Published by: **HL7 International - Public Health Work Group** 

This is a CapabilityStatement that defines the expected capabilities of the Data Source actor. 

## General

* FHIR Version:: Supported formats:
  * 4.0.1: json

## REST behavior

The primary focus of the Data Source is to identify the population of patients whose data needs to be reported to UDS+ program, and allow the export of UDS+ data using US Core and UDS+ profiles and US Core APIs. Data Sources that incorporate the Trust Service Provider and the Data Submitter modules **SHOULD** support the UDS+ profiles. Data Sources that provide data to external Data Submitters and Trust Service Providers **SHOULD** support US Core profiles and **MAY** support UDS+ profiles. 

 **Security:** 

Implementations must meet the general security requirements documented in FHIR [Security guidance](http://hl7.org/fhir/security.html).

In addition the Data Source actor needs to meet the security requirements as outlined in the [SMART on FHIR Backend Services Authorization](spec.md#smart-on-fhir-backend-services-authorization)

### Resource summary


### FHIR Operations summary

The following FHIR operations SHALL be supported by the Data Source.

*  [Bulk Data Export ([BaseURL]/Group/[Id]/$export)](http://hl7.org/fhir/uv/bulkdata/OperationDefinition-group-export.html) 

###  UDS+ profiles 

Profiles: All UDS+ profiles 

#### Interactions

*  search:  read
  * Allows searching of specific UDS+ or US Core profile instances.: Allows retrieval of specific UDS+ or US Core profile instances



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "uds-plus-data-source",
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-source",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusDataSource",
  "title" : "Uds Plus Data Source CapabilityStatement",
  "status" : "draft",
  "date" : "2020-12-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "This is a CapabilityStatement that defines the expected capabilities of the Data Source actor.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "rest" : [{
    "mode" : "server",
    "documentation" : "The primary focus of the Data Source is to identify the population of patients whose data needs to be reported to UDS+ program, and allow the export of UDS+ data using US Core and UDS+ profiles and US Core APIs.",
    "security" : {
      "description" : "Implementations must meet the general security requirements documented in the security section of the implementation guide."
    },
    "operation" : [{
      "name" : "export",
      "definition" : "http://hl7.org/fhir/uv/bulkdata/OperationDefinition/group-export"
    }]
  }]
}

```
