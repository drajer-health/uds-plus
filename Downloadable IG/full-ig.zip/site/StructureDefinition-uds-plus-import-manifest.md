# UDS Plus Import Manifest - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Import Manifest**

## Resource Profile: UDS Plus Import Manifest 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-import-manifest | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusImportManifest |

 
The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Manifest for UDS+ import FHIR Operations. 

### Introduction

This profile is used to represent the manifest file information that is submitted to the $import operation.

**Representing Health Center Information**

Health Centers have to provide the following information as part of the manifest.

* UEI Number: Unique Entity Identifier (UEI) is a unique number assigned by SAM (System for Awards Management) to all entities who register to do business with the federal government.
* Grant Number: This is comprised of the activity code and the serial number for the particular grant. This number, once assigned does not change for the life of the grant. The activity code which is used to form the static grant number is the activity code which the grant is currently tied to. When a new grant is created, the static Grant Number now gets populated from within the code. Examples of grant numbers include "H80CS##### and LALCS#####" where the [#####] is substituted with the actual value.
* Health Center Contact Person has to be provided with a First and Last Name.
* Health Center Address has to be provided.
* Health Center Contact phone number has to be provided.

**Providing Security Tokens**

A Health Center may wish to make sure that the HRSA Data Receiver provide a security token during the download of the UDS Plus data. In order to facilitate these tokens, the Data Submitter may echo a "security token" of type "bearer" in the manifest file for each UDS Plus file that needs to be downloaded. This bearer token will be echo'ed back by the Data Receiver in the HTTP header during the download process. This further enhances the security protocols between the Data Submitter and the Data Receiver systems.

**Submitting data for multiple sites and/or EHRs that are part of a Health Center**

There are many instances where a Health Center may be using one or more EHR technology and would like to submit data individually from each EHR separately and let HRSA aggregate the data for the Health Center. In addition, some Health Centers report data by sites where services are rendered. The Manifest file submitted to the [$import](OperationDefinition-import.md) operation provides the following data elements to properly identify these scenarios during the submission.

****partialSubmission attribute in Manifest****

The partialSubmission attribute should be included in the Manifest file and set to a value of "true" for the following scenarios:

* Health Center will be submitting data from multiple EHRs independent of each other but HRSA has to aggregate the data across the submissions for the final counts.
* Health Center will be submitting data from multiple sites where services are rendered independent of each other but HRSA has to aggregate the data across the submissions for the final counts.

The partialSubmission flag of "true" indicates to HRSA that there will be multiple submissions using the same "grantNumber". After the submission period, HRSA will aggregate the multiple submissions and provide feedback on the submitted data. Health Centers do not have to include this attribute if there is only one submission from the Health Center.

****Re-submissions of the data****

If a Health Center wishes to resubmit data, then the replaceSubmissionId attribute has to be included and has to contain the previous submissionId which this submission is replacing.

****Relationship between partialSubmission and Re-Submission****

A submission can be tagged as a partial submission and also as a replacement to a previous submission.

****IncrementalData Flag****

Sometimes, a submission may have errors with a small set of records in which case, the entire submission need not be resubmitted.The DataSubmitters can submit only the corrected records and indicate to the Data Receiver to replace only the subset of the records. When the incrementalData flag is set, the replaceSubmissionId has to be populated.

The DataReceiver performs the following activities:

* Finds the original submission based on the replaceSubmissionId
* Finds the records using the FHIR Resource Ids.
* Replace the data for the records
* If the records are not found, then the records are added into the submission
* Perform validation of the modified submission and report the success or failures/errors.

NOTE: Incremental submissions will be accepted in the future. It is included in this version of the IG to collect feedback from the vendor community of the approach.

**Usages:**

* Examples for this Profile: [Parameters/example](Parameters-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir.hrsa.uds-plus|current/StructureDefinition/StructureDefinition-uds-plus-import-manifest.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-uds-plus-import-manifest.csv), [Excel](StructureDefinition-uds-plus-import-manifest.xlsx), [Schematron](StructureDefinition-uds-plus-import-manifest.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "uds-plus-import-manifest",
  "meta" : {
    "versionId" : "12",
    "lastUpdated" : "2022-07-12T02:03:11.293+00:00",
    "source" : "#3LDMUQYYwafwTzqK"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-import-manifest",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusImportManifest",
  "title" : "UDS Plus Import Manifest",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-13T10:51:25+00:00",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Manifest for UDS+ import FHIR Operations.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Parameters",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Parameters",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Parameters",
      "path" : "Parameters",
      "short" : "UDS Plus Import Manifest",
      "definition" : "The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Manifest for UDS+ import FHIR Operations."
    },
    {
      "id" : "Parameters.parameter",
      "path" : "Parameters.parameter",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 6,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:inputFormat",
      "path" : "Parameters.parameter",
      "sliceName" : "inputFormat",
      "short" : "Parameter used to define the Mime Type of the data contained within the submitted files",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:inputFormat.name",
      "path" : "Parameters.parameter.name",
      "short" : "The parameter name for the Mime Type",
      "min" : 1,
      "max" : "1",
      "fixedString" : "inputFormat",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:inputFormat.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "The Mime type of the data contained within the submitted files",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "fixedCode" : "fhir+ndjson",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionId",
      "path" : "Parameters.parameter",
      "sliceName" : "submissionId",
      "short" : "Parameter to convey the unique submission identifier",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionId.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name for submission identifier",
      "min" : 1,
      "max" : "1",
      "fixedString" : "submissionId",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionId.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "Submission Identifier value",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:productInformation",
      "path" : "Parameters.parameter",
      "sliceName" : "productInformation",
      "short" : "Parameter to convey the product acting as the UDS+ data source actor.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:productInformation.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name for submitters to populate the data source name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "productName",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:productInformation.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "UDS+ Data Source Actor name",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:developerInformation",
      "path" : "Parameters.parameter",
      "sliceName" : "developerInformation",
      "short" : "Parameter to convey the vendor who is providing the UDS+ Data Source system",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:developerInformation.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name for vendor providing the UDS+ Data Source system",
      "min" : 1,
      "max" : "1",
      "fixedString" : "developerName",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:developerInformation.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "The vendor's name who is providing the UDS+ Data Source system",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submitterEntityInformation",
      "path" : "Parameters.parameter",
      "sliceName" : "submitterEntityInformation",
      "short" : "Parameter to convey the entity who is submitting the data on behalf of the health center",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submitterEntityInformation.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name for the entity who is submitting the data on behalf of the health center",
      "min" : 1,
      "max" : "1",
      "fixedString" : "submitterEntityName",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submitterEntityInformation.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "The entity's name who is submitting the data on behalf of the health center",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionTime",
      "path" : "Parameters.parameter",
      "sliceName" : "submissionTime",
      "short" : "Parameter to convey the submission time of the manifest resource to '$import' operation",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionTime.name",
      "path" : "Parameters.parameter.name",
      "short" : "Name of the parameter to convey the submission time",
      "min" : 1,
      "max" : "1",
      "fixedString" : "submissionTime",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:submissionTime.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "Submission Time value",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:replaceSubmissionId",
      "path" : "Parameters.parameter",
      "sliceName" : "replaceSubmissionId",
      "short" : "Parameer to identify the previous submission data that needs to be replaced with this submission",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:replaceSubmissionId.name",
      "path" : "Parameters.parameter.name",
      "short" : "Name of the parameter to convey the submission that needs to be replaced",
      "min" : 1,
      "max" : "1",
      "fixedString" : "replaceSubmissionId",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:replaceSubmissionId.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "Actual value of the previous submission that needs to be replaced",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmission",
      "path" : "Parameters.parameter",
      "sliceName" : "partialSubmission",
      "short" : "Parameter to indicate if the submission has to be treated as a partial submission for the Health Center",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmission.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name to indicate that this ia a partial submission",
      "min" : 1,
      "max" : "1",
      "fixedString" : "partialSubmission",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmission.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "Actual value indicating if this is a partial submission",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmissionName",
      "path" : "Parameters.parameter",
      "sliceName" : "partialSubmissionName",
      "short" : "Parameter that can be used by the Health Center to identify the partial submission, for e.g EHR product name or site name",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmissionName.name",
      "path" : "Parameters.parameter.name",
      "short" : "The Parameter name to convey the partial submission name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "partialSubmissionName",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:partialSubmissionName.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "short" : "Actual partial submission name",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation",
      "path" : "Parameters.parameter",
      "sliceName" : "hcInformation",
      "short" : "Parameters to convey the Health Center information",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.name",
      "path" : "Parameters.parameter.name",
      "short" : "Parameter that holds the Health Center information",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcInformation",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part",
      "path" : "Parameters.parameter.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 7,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:ueiNumber",
      "path" : "Parameters.parameter.part",
      "sliceName" : "ueiNumber",
      "short" : "Parameter to convey the UEI number for the Health Center",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:ueiNumber.name",
      "path" : "Parameters.parameter.part.name",
      "short" : "Parameter that indicates this is an UEI number",
      "min" : 1,
      "max" : "1",
      "fixedString" : "uei",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:ueiNumber.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "short" : "Actual UEI value",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:grantNumber",
      "path" : "Parameters.parameter.part",
      "sliceName" : "grantNumber",
      "short" : "Parameter to convey the GRANT number of the Health Center",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:grantNumber.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "grantNumber",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:grantNumber.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcName",
      "path" : "Parameters.parameter.part",
      "sliceName" : "hcName",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcName.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcName",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcName.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress",
      "path" : "Parameters.parameter.part",
      "sliceName" : "hcAddress",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcAddress",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Address"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.value[x].line",
      "path" : "Parameters.parameter.part.value[x].line",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.value[x].city",
      "path" : "Parameters.parameter.part.value[x].city",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.value[x].state",
      "path" : "Parameters.parameter.part.value[x].state",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcAddress.value[x].postalCode",
      "path" : "Parameters.parameter.part.value[x].postalCode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPerson",
      "path" : "Parameters.parameter.part",
      "sliceName" : "hcContactPerson",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPerson.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcContactPerson",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPerson.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "HumanName"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPerson.value[x].family",
      "path" : "Parameters.parameter.part.value[x].family",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPerson.value[x].given",
      "path" : "Parameters.parameter.part.value[x].given",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPhone",
      "path" : "Parameters.parameter.part",
      "sliceName" : "hcContactPhone",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPhone.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcContactPhone",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPhone.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "ContactPoint"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPhone.value[x].system",
      "path" : "Parameters.parameter.part.value[x].system",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "fixedCode" : "phone",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcContactPhone.value[x].value",
      "path" : "Parameters.parameter.part.value[x].value",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcPrenatalCareByReferralOnly",
      "path" : "Parameters.parameter.part",
      "sliceName" : "hcPrenatalCareByReferralOnly",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcPrenatalCareByReferralOnly.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "hcPrenatalCareByReferralOnly",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:hcInformation.part:hcPrenatalCareByReferralOnly.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:importProtocol",
      "path" : "Parameters.parameter",
      "sliceName" : "importProtocol",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:importProtocol.name",
      "path" : "Parameters.parameter.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "importProtocol",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:importProtocol.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "fixedCode" : "https",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData",
      "path" : "Parameters.parameter",
      "sliceName" : "udsData",
      "min" : 1,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.name",
      "path" : "Parameters.parameter.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "udsData",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part",
      "path" : "Parameters.parameter.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceType",
      "path" : "Parameters.parameter.part",
      "sliceName" : "resourceType",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceType.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "type",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceType.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrl",
      "path" : "Parameters.parameter.part",
      "sliceName" : "resourceUrl",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrl.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "url",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrl.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "url"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrlExpirationTime",
      "path" : "Parameters.parameter.part",
      "sliceName" : "resourceUrlExpirationTime",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrlExpirationTime.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "expirationTime",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:resourceUrlExpirationTime.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:importAccessToken",
      "path" : "Parameters.parameter.part",
      "sliceName" : "importAccessToken",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:importAccessToken.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "bearer",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:importAccessToken.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:incrementalData",
      "path" : "Parameters.parameter.part",
      "sliceName" : "incrementalData",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:incrementalData.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "incrementalData",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:udsData.part:incrementalData.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    }]
  }
}

```
