# UDS Plus Insurance Codes - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Insurance Codes**

## CodeSystem: UDS Plus Insurance Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CodeSystem/uds-plus-insurance-codes | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusInsuranceCodes |

 
The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying insurance types used by patients in UDS+ program. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Uds Plus Insurance Codes](ValueSet-uds-plus-insurance-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "uds-plus-insurance-codes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/uds-plus-insurance-codes",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusInsuranceCodes",
  "title" : "UDS Plus Insurance Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-09-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying insurance types used by patients in UDS+ program.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 9,
  "concept" : [{
    "code" : "none-or-uninsured",
    "display" : "None or Uninsured",
    "definition" : "Patient does not have insurance"
  },
  {
    "code" : "medicaid-title-19-21",
    "display" : "Medicaid Title X1X",
    "definition" : "Patients with Medicaid (Title X1X) insurance"
  },
  {
    "code" : "chip-medicaid",
    "display" : "CHIP Medicaid",
    "definition" : "Patients with CHIP Medicaid insurance"
  },
  {
    "code" : "medicare",
    "display" : "Medicare",
    "definition" : "Patients with Medicare insurance"
  },
  {
    "code" : "dually-eligible-medicaid-medicare",
    "display" : "Dually Eligible",
    "definition" : "Patients with both Medicare and Medicaid"
  },
  {
    "code" : "medicare-and-private",
    "display" : "Medicare and Private",
    "definition" : "Patients with both Medicare and Private insurance such as Medigap"
  },
  {
    "code" : "other-non-chip-public-insurance",
    "display" : "Other Non CHIP Public Insurance",
    "definition" : "Patients who have other public insurance which is non CHIP"
  },
  {
    "code" : "other-public-insurance-chip",
    "display" : "Other Public Insurance CHIP",
    "definition" : "Patients who have other public insurance which is CHIP"
  },
  {
    "code" : "private-insurance",
    "display" : "Private Insurance",
    "definition" : "Patients has Private Insurance"
  }]
}

```
