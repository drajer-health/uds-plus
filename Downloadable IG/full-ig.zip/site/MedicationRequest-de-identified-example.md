# Uds Plus MedicationRequest Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus MedicationRequest Example**

## Example MedicationRequest: Uds Plus MedicationRequest Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "MedicationRequest",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-medicationrequest"]
  },
  "status" : "active",
  "intent" : "order",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "476872",
      "display" : "Nizatidine 15 MG/ML Oral Solution"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "encounter" : {
    "reference" : "Encounter/de-identified-example"
  },
  "authoredOn" : "2008",
  "requester" : {
    "reference" : "Practitioner/example"
  },
  "dosageInstruction" : [{
    "text" : "10 mL bid",
    "timing" : {
      "repeat" : {
        "boundsPeriod" : {
          "start" : "2008-04-05"
        },
        "frequency" : 2,
        "period" : 1,
        "periodUnit" : "d"
      }
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 10,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      }
    }]
  }]
}

```
