# UDS Plus Parameters Example for $deidentify operation - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Parameters Example for $deidentify operation**

## Example Parameters: UDS Plus Parameters Example for $deidentify operation



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "de-identify-data-operation-urls-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentify-operation-data-urls-parameter"]
  },
  "parameter" : [{
    "name" : "format",
    "valueCode" : "fhir+ndjson"
  },
  {
    "name" : "udsData",
    "part" : [{
      "name" : "resourceType",
      "valueCode" : "Patient"
    },
    {
      "name" : "resourceUrl",
      "valueUrl" : "http://example.com/Patient.ndjson"
    }]
  }]
}

```
