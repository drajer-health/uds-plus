# UDS Plus Import - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Import**

## OperationDefinition: UDS Plus Import 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/OperationDefinition/import | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusImport |

 
Notification from a Health Center about the availability of the data to HRSA using Bulk Import mechanism. 

### Introduction

The import operation is to be used by the Health Centers to submit data to HRSA. The import operation takes a [Manifest](StructureDefinition-uds-plus-import-manifest.md) which contains the links of all the data that needs to be submitted to HRSA. This import operation resembles the Bulk Import operation proposed by the Bulk Data team but is not currently part of the FHIR specifications or Implementation Guides.

The Health Center can also check on the status of the import operation using the status location provided in the import response. This allows the Health Center to determine if the data has been successfully imported and validated by HRSA.

In this version of the IG only the NDJSON files are supported as the file format and the protocol to be used for importing is HTTPS with appropriate authorization.



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "import",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/OperationDefinition/import",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusImport",
  "title" : "UDS Plus Import",
  "status" : "active",
  "kind" : "operation",
  "date" : "2021-07-22T21:48:56+10:00",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "Notification from a Health Center about the availability of the data to HRSA using Bulk Import mechanism.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "code" : "import",
  "base" : "http://fhir.org/guides/hrsa/uds-plus/OperationDefinition/import",
  "system" : true,
  "type" : false,
  "instance" : false,
  "parameter" : [{
    "name" : "importInformation",
    "use" : "in",
    "min" : 1,
    "max" : "1",
    "documentation" : "The links and other metadata related to the data exported by the health center.",
    "type" : "Parameters"
  }]
}

```
