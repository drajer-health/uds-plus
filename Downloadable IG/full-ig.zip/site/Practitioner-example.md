# US Core Practitioner Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Practitioner Example**

## Example Practitioner: US Core Practitioner Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

**Practitioner** 

Resource Practitioner "practitioner-1" 

**identifier**: id: 9941339100, id: 25456

**name**: Ronald Bone 

**address**: 1003 Healthcare Drive Amherst MA 01002 (WORK)



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "example",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner"]
  },
  "identifier" : [{
    "system" : "http://hl7.org/fhir/sid/us-npi",
    "value" : "9941339100"
  }],
  "name" : [{
    "family" : "Bone",
    "given" : ["Ronald"],
    "prefix" : ["Dr"]
  }],
  "address" : [{
    "use" : "work",
    "line" : ["1003 Healthcare Drive"],
    "city" : "Amherst",
    "state" : "MA",
    "postalCode" : "01002"
  }]
}

```
