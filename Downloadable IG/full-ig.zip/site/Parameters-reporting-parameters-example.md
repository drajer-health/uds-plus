# UDS Plus Reporting Parameters Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Reporting Parameters Example**

## Example Parameters: UDS Plus Reporting Parameters Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "reporting-parameters-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-patient-reporting-parameters"]
  },
  "parameter" : [{
    "name" : "patientReference",
    "valueReference" : {
      "reference" : "Patient/de-identified-example"
    }
  },
  {
    "name" : "combinedFundingStreams",
    "valueString" : "CHC,MHC"
  },
  {
    "name" : "reportNames",
    "part" : [{
      "name" : "patientsByZip",
      "valueBoolean" : true
    },
    {
      "name" : "table3A",
      "valueBoolean" : true
    },
    {
      "name" : "table3B",
      "valueBoolean" : true
    },
    {
      "name" : "table4",
      "valueBoolean" : true
    },
    {
      "name" : "table6A",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line1-6-Age-Of-Prenatal-Care-Patients",
      "valueBoolean" : false
    },
    {
      "name" : "table6B-Line7-9-Early-Entry-Into-Prenatal-Care",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line10-Childhood-Immunization-Status-CMS117",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line11-Cervical-Cancer-Screening-CMS124",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line11a-Breast-Cancer-Screening-CMS125",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line12-Weight-Assessment-And-Counselling-CMS155",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line14a-Preventive-Care-And-Screening-Tobacco-Use-CMS138",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line17a-Statin-Therapy-CMS347",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line18-Ischmic-Vascular-Disease-CMS164",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line19-Colorectal-Cancer-Screening-CMS130",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line20-HIV-Linkage-To-Care",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line20a-HIV-Screening-CMS349",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line21-Preventive-Care-And-Screening-For-Depression-CMS2",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line21a-Depression-Remission-At-Twelve-Months-CMS159",
      "valueBoolean" : true
    },
    {
      "name" : "table6B-Line22-Dental-Sealants-For-Children-CMS277",
      "valueBoolean" : true
    },
    {
      "name" : "table7-Line0-HIV-Positive-Pregnant-Patients",
      "valueBoolean" : true
    },
    {
      "name" : "table7-Line2-Deliveries-Performed-By-Health-Center",
      "valueBoolean" : true
    },
    {
      "name" : "table7-Line1a-d-Prenatal-Care-Patient-Deliveries",
      "valueBoolean" : true
    },
    {
      "name" : "table7-Line2a-c-Controlling-High-Blood-Pressure-CMS165",
      "valueBoolean" : true
    },
    {
      "name" : "table7-Line3a-f-HbA1c-Poor-Control-CMS122",
      "valueBoolean" : true
    }]
  }]
}

```
