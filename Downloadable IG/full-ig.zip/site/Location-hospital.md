# US Core Location Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Location Example**

## Example Location: US Core Location Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

** Location** 

Resource Location "hospital" 

**status**: active

**name**: Holy Family Hospital

**telecom**: ph: 9786870156

**address**: 70 EAST STREET METHUEN MA 01844 US 

**managingOrganization**: [Organization/holy-healthcare: Holy Healthcare](Organization-holy-healthcare.md) "Holy Healthcare"



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "hospital",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-location",
    "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-location"]
  },
  "status" : "active",
  "name" : "Holy Family Hospital",
  "telecom" : [{
    "system" : "phone",
    "value" : "9786870156"
  }],
  "address" : {
    "line" : ["70 EAST STREET"],
    "city" : "METHUEN",
    "state" : "MA",
    "postalCode" : "01844",
    "country" : "US"
  },
  "managingOrganization" : {
    "reference" : "Organization/holy-healthcare",
    "display" : "Holy Healthcare"
  }
}

```
