# Change History - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* **Change History**

## Change History

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

### Change History

The following is a list of all the changes based on versions.

#### Changes made from 1.1.0 to 2.0.0

1. Added validations for ensuring dates are in the range between 1900 and 2030
1. Added validations for postalCode to ensure only digits are supported for both regular and extended format.
1. Added validations for Age to be > 0
1. Allowed for null flavors in Coverage.type value set
1. Added validations for income observations to ensure data is represented as per the specification
1. Added example for income observation with only Range.high values
1. Removed Gender Identity extension and related artifacts
1. Removed Sexual Orientation profile and related artifacts
1. Added school-based site as a service delivery location
1. Added uds-plus-sex-extension to be used instead of uds-plus-birthsex-extension.
1. Updated uds-plus-sex-codes to accommodate the CMS Sex codes value set.
1. Updated eCQM versions in DataElements table to match the 2024 UDS Manual.

#### Changes made from 1.0.0 to 1.1.0

1. Added support for Partial Submissions supporting Health Centers with multiple EHRs and/or multiple reporting sites.
1. Added support for incremental submissions to support efficient data corrections during resubmissions.
1. Added support for re-submissions with partial and incremental submission concepts
1. Added uds-plus-observation to support Assessments, Vitals, Physical Exams and Social History observations. - #24
1. Added guidance for de-identification of patients > 89 years.
1. Added Live Birth weight LOINC code to UDS Data Elements Mapping Table. - #32
1. Updated Breast Cancer Screening Mappings to remove Result entries. - #33
1. Updated Medication, Active mappings to use either MedicationStatement or MedicationRequest to align with US Core. - #26
1. Added clarifications on UDS+ and US Core relationships. - #1
1. Added guidance on Encounter reason and service Provider organization. - #2
1. Updated UDS+ Encounter profile to allow multiple participants to be compatible with US Core. - #4
1. Updated UDS+ Data Elements Table Header to point to the right US Core version of 6.1.0 - #5
1. Removed Bodysite data element from ServiceRequest as MUST SUPPORT - #30
1. Added guidance on removing submitted files. - #23
1. Added additional guidance on quality reporting. - #15
1. Updated Age related constraints in the profiles to follow de-identification requirements.
1. Updated all profiles to add constraints related to dates, Periods and Timing to follow de-identification requirements.
1. Added extension to support de-identified instant data type, which is used in Observations to capture instant with a precision upto YEAR only.

#### Changes made from 1.0.0 to 1.0.1

1. Removed mentions of alternate submission mechanisms from Background.
1. Clarified MUST SUPPORT definition in the specification to deal with data elements that may not be present in the mapping tables but are present in the UDS+ profiles.
1. Updated Coverage to make capitatedMemberMonths and feeForServiceMemberMonths as optional.
1. Added clarifications on Income Observation to represent > 200% using valueQuantity instead of valueRange.
1. Change Income Observation to allow valueQuantity along with valueRange.
1. Added explicit requirements to Data Submitter to not submit data elements not specified in the UDS+ profiles.
1. Added explicit requirements to Data Receiever to reject submission when a Data Submitter submits data elements not specified in the UDS+ profiles.
1. Removed aggregate reporting option from reporting guidance.
1. Added clarification to Data Submitter quality reporting to include only patients who meet the criteria for the Initial Patient Population.
1. Added partial submission requirements as part of the Data Submitter requirements.
1. Added partial submission requirement validation for Data Receiver.
1. Added information for on-boarding process as part of the reporting guidance.
1. Added submissionTime to Manifest file.
1. Updated data mapping tables to remove blank rows and mappings not necessary.
1. Added examples for Requests and Responses as part of the Implementation Guidance.
1. Updated capability statements to use UDS+ profiles instead of US Core profiles.

#### Changes made from 0.4.1 to 1.0.0

1. Added cardinality constraints for Healthcare information in the Manifest file.
1. Enhanced Race, Ethnicity, Birth Sex, Sexual Orientation, Gender Identity constraints for inferno based testing and updated examples.
1. Added prenatalReferralOnly Indicator to Manifest file.
1. Added guidance in mapping tables for Prenatal data and Live Birth Weight data.
1. Removed dependencies on QI core and enabled QI core extensions within UDS+ IG on Procedure.
1. Added guidance for school based service location indication on Encounter page.
1. Removed RelatedPerson demographics information as it is not needed for De-Identified Coverage.
1. Fixed errors related to the Build to enable AdverseEvent, AllergyIntolerance and Observation profiles for Diagnostic Studies.

#### Changes made from 0.4.0 to 0.4.1

1. Changed grantId to grantNumber in Manifest file.
1. Added Health Center Contact Person Name, Health Center Address and Contact Person's Phone in Manifest.
1. Added support for bearer token as part of the protocol for each resource link.
1. Added support for funding streams as part of the Reporting Parameters profile.
1. Added support for all reports in the Reporting Parameters profile.
1. Added notes for Manifest and Reporting Parameters profiles.
1. Added eCQM mappings for HbA1c poor control(CMS122) and Controlling High Blood Pressure.(CM165)
1. Updated examples fixing errors for all UDS Plus De-identified resources.
1. Fixed issues with MedicationRequest and MedicationStatement profiles to enable their display.

#### Changes made from 0.3.0 to 0.4.0

1. Added dataAbsentReason for Patient.address.postalCode to support masking and reporting for UDS+
1. Added InsuranceCodes for Coverage resource profile to match values needed for UDS+ tables
1. Added preferredIndicator to Patient.language for computation of Table 3B
1. Verified support for 2023 reporting Race and Ethnicity Values derivation for Table 3B
1. Updated Coverage Resource profile
1. Changed USCore dependency from 5.0.1 to 6.0.0 (USCDI v3)
1. Updated Data Element Mappings.
1. Added guidance for Race, Ethnicity, Sexual Orientation and Gender Identity.
1. Added support for dataAbsentReason for IncomeObservation
1. Added extensions to Coverage for capitation months and fee for service months for Table 4.
1. Added mappings for the IVD, HIV Linkage to Care and Dental Sealants measures.
1. Added Grant Number, Health Center Id, Health Center Name to the Manifest
1. Added ability to identify a patient as part of specific tables and reports.

#### Changes for 0.3.0

1. Updated Use Case Diagram to show the polling of status.
1. Added paragraph on re-submission of UDS+ reports
1. Added paragraph on the submission process and the flexibility to implement Steps 1 through 9 of the Use Case workflow.
1. Updated implementation guidance with sequence diagrams for Step 9 and 10a, 10b.
1. Updated Data Source Requirements for SMART on FHIR and Group Export operation requirements
1. Updated Data Source Requirements to specify Group Management capabilities.
1. Updated Trust Service Provider requirements for de-identification.
1. Updated Data Receiver Requirements for re-submission.
1. Added Table specific guidance in the reporting guidance.
1. Removed Implementation Notes and consolidated to Reporting Guidance.
1. Added examples for De-identified profiles.
1. Added examples for UDS+ File Manifest.
1. Updated the following profiles
* Patient, Encounter, Condition, Parameters - Manifest

#### Changes for 0.2.0

1. Addition of profiles for De-identified patient data. (Added extensions for agriculture worker status, gender identity, housing status)
1. Addition of linkages from abstract model to implementation details.
1. Added Change History.
1. Addition of codesystems for Agriculture Worker Status, Insurance Type. Housing status.

