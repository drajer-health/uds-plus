# Useful Downloads - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* **Useful Downloads**

## Useful Downloads

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

### Download

You can also download:

* [this entire guide](full-ig.zip)
* the definition resources in [json](definitions.json.zip), [xml](definitions.xml.zip), [ttl](definitions.ttl.zip), or [csv](csvs.zip) format, or
* the example resources in [json](examples.json.zip), [xml](examples.xml.zip) or [ttl](examples.ttl.zip) format.

#### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (fhir.hrsa.uds-plus.r4)](package.r4.tgz) and [R4B (fhir.hrsa.uds-plus.r4b)](package.r4b.tgz) are available.

#### Dependency Table










#### Globals Table

*There are no Global profiles defined*

#### IP Statements

This publication includes IP covered under the following statements.

* Current Procedural Terminology (CPT) is copyright 2020 American Medical Association. All rights reserved

* [Current Procedural Terminology (CPT®)](http://terminology.hl7.org/5.5.0/CodeSystem-CPT.html): [Encounter/de-identified-example](Encounter-de-identified-example.md)


* Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission. For information and exceptions regarding use of CDC material please see [[https://www.cdc.gov/other/agencymaterials.html](https://www.cdc.gov/other/agencymaterials.html)](https://www.cdc.gov/other/agencymaterials.html) 

* [Vaccine Administered Code Set (CVX)](http://terminology.hl7.org/5.5.0/CodeSystem-CVX.html): [Immunization/de-identified-example](Immunization-de-identified-example.md)


* Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission.For information and exceptions regarding use of CDC material please see [https://www.cdc.gov/other/agencymaterials.html](https://www.cdc.gov/other/agencymaterials.html).

* [CDC Race and Ethnicity](http://terminology.hl7.org/5.5.0/CodeSystem-CDCREC.html): [Patient/de-identified-age89-example](Patient-de-identified-age89-example.md), [Patient/de-identified-example](Patient-de-identified-example.md), [Patient/de-identified-smallpop-example](Patient-de-identified-smallpop-example.md), [Patient/example](Patient-example.md) and [Patient/smallpop-example](Patient-smallpop-example.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/5.5.0/CodeSystem-v3-ucum.html): [Coverage/de-identified-example](Coverage-de-identified-example.md), [Encounter/de-identified-example](Encounter-de-identified-example.md)... Show 8 more, [MedicationRequest/de-identified-example](MedicationRequest-de-identified-example.md), [MedicationStatement/de-identified-example](MedicationStatement-de-identified-example.md), [Observation/clinical-result-de-identified-example](Observation-clinical-result-de-identified-example.md), [Observation/de-identified-example](Observation-de-identified-example.md), [Observation/de-identified-income-with-quantity-example](Observation-de-identified-income-with-quantity-example.md), [Patient/de-identified-age89-example](Patient-de-identified-age89-example.md), [Patient/de-identified-example](Patient-de-identified-example.md) and [Patient/de-identified-smallpop-example](Patient-de-identified-smallpop-example.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/5.5.0/CodeSystem-v3-loinc.html): [Observation/clinical-result-de-identified-example](Observation-clinical-result-de-identified-example.md), [Observation/de-identified-example](Observation-de-identified-example.md), [Observation/de-identified-income-example](Observation-de-identified-income-example.md), [Observation/de-identified-income-with-quantity-example](Observation-de-identified-income-with-quantity-example.md) and [Observation/de-identified-low-income-example](Observation-de-identified-low-income-example.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AdverseEvent/de-identified-example](AdverseEvent-de-identified-example.md), [AllergyIntolerance/de-identified-example](AllergyIntolerance-de-identified-example.md)... Show 5 more, [Observation/de-identified-example](Observation-de-identified-example.md), [Observation/generic-observation-de-identified-example](Observation-generic-observation-de-identified-example.md), [Procedure/de-identified-example](Procedure-de-identified-example.md), [ServiceRequest/de-identified-example](ServiceRequest-de-identified-example.md) and [UdsPlusSexCodes](ValueSet-uds-plus-sex-codes.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AdverseEventCategory](http://terminology.hl7.org/7.1.0/CodeSystem-adverse-event-category.html): [AdverseEvent/de-identified-example](AdverseEvent-de-identified-example.md)
* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.1.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/de-identified-example](AllergyIntolerance-de-identified-example.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.1.0/CodeSystem-allergyintolerance-verification.html): [AllergyIntolerance/de-identified-example](AllergyIntolerance-de-identified-example.md)
* [Condition Category Codes](http://terminology.hl7.org/7.1.0/CodeSystem-condition-category.html): [Condition/de-identified-example](Condition-de-identified-example.md), [Condition/example](Condition-example.md) and [Immunization/de-identified-example](Immunization-de-identified-example.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.1.0/CodeSystem-condition-clinical.html): [Condition/de-identified-example](Condition-de-identified-example.md) and [Condition/example](Condition-example.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.1.0/CodeSystem-condition-ver-status.html): [Condition/de-identified-example](Condition-de-identified-example.md) and [Condition/example](Condition-example.md)
* [Observation Category Codes](http://terminology.hl7.org/7.1.0/CodeSystem-observation-category.html): [Observation/clinical-result-de-identified-example](Observation-clinical-result-de-identified-example.md), [Observation/de-identified-example](Observation-de-identified-example.md) and [Observation/generic-observation-de-identified-example](Observation-generic-observation-de-identified-example.md)
* [Organization type](http://terminology.hl7.org/7.1.0/CodeSystem-organization-type.html): [Acme Health Plan](Organization-acme-payer.md) and [Holy Healthcare](Organization-holy-healthcare.md)
* [identifierType](http://terminology.hl7.org/7.1.0/CodeSystem-v2-0203.html): [Patient/example](Patient-example.md) and [Patient/smallpop-example](Patient-smallpop-example.md)
* [ActCode](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html): [Encounter/de-identified-example](Encounter-de-identified-example.md) and [Encounter/example](Encounter-example.md)
* [AdministrativeGender](http://terminology.hl7.org/7.1.0/CodeSystem-v3-AdministrativeGender.html): [UdsPlusSexCodes](ValueSet-uds-plus-sex-codes.md)
* [NullFlavor](http://terminology.hl7.org/7.1.0/CodeSystem-v3-NullFlavor.html): [Patient/example](Patient-example.md), [Patient/smallpop-example](Patient-smallpop-example.md) and [UdsPlusInsuranceCodes](ValueSet-uds-plus-insurance-codes.md)
* [RoleCode](http://terminology.hl7.org/7.1.0/CodeSystem-v3-RoleCode.html): [RelatedPerson/de-identified-example](RelatedPerson-de-identified-example.md)


* Using RxNorm codes of type SAB=RXNORM as this specification describes does not require a UMLS license. Access to the full set of RxNorm definitions, and/or additional use of other RxNorm structures and information requires a UMLS license. The use of RxNorm in this specification is pursuant to HL7's status as a licensee of the NLM UMLS. HL7's license does not convey the right to use RxNorm to any users of this specification; implementers must acquire a license to use RxNorm in their own right.

* [RxNorm](http://terminology.hl7.org/5.5.0/CodeSystem-v3-rxNorm.html): [MedicationRequest/de-identified-example](MedicationRequest-de-identified-example.md) and [MedicationStatement/de-identified-example](MedicationStatement-de-identified-example.md)


