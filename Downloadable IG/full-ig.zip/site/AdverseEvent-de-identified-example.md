# UDS Plus AdverseEvent Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus AdverseEvent Example**

## Example AdverseEvent: UDS Plus AdverseEvent Example



## Resource Content

```json
{
  "resourceType" : "AdverseEvent",
  "id" : "de-identified-example",
  "meta" : {
    "lastUpdated" : "2017-05-26T11:56:57.250-04:00",
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-adverseevent"]
  },
  "actuality" : "actual",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/adverse-event-category",
      "code" : "medication-mishap",
      "display" : "Medication Mishap"
    }],
    "text" : "Medication Mishap - Wrong Dose"
  }],
  "event" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "140004",
      "display" : "Chronic Pharyngitis"
    }],
    "text" : "Chronic Pharyngitis"
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "date" : "2015",
  "detected" : "2030",
  "recordedDate" : "2017"
}

```
