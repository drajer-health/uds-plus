# Uds Plus De-Identified Encounter Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus De-Identified Encounter Example**

## Example Encounter: Uds Plus De-Identified Encounter Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "de-identified-example",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "De-Identified Encounter Example"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This is an encounter example for the *US Core Encounter Profile*."
    }],
    "lastUpdated" : "2022-05-26T11:56:57.250-04:00",
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-encounter"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-age-extension",
    "valueQuantity" : {
      "value" : 36,
      "unit" : "yr",
      "system" : "http://unitsofmeasure.org",
      "code" : "a"
    }
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB",
    "display" : "ambulatory"
  },
  "type" : [{
    "coding" : [{
      "system" : "http://www.ama-assn.org/go/cpt",
      "code" : "99202"
    }]
  }],
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "period" : {
    "start" : "2022",
    "end" : "2022"
  },
  "hospitalization" : {
    "dischargeDisposition" : {
      "coding" : [{
        "system" : "http://www.nubc.org/patient-discharge",
        "code" : "01",
        "display" : "Discharged to Home"
      }]
    }
  },
  "location" : [{
    "location" : {
      "reference" : "Location/hospital",
      "display" : "Holy Family Hospital"
    }
  }]
}

```
