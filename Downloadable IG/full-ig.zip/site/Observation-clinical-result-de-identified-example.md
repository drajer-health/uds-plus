# UDS Plus ClinicalResult Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus ClinicalResult Example**

## Example Observation: UDS Plus ClinicalResult Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "clinical-result-de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-clinical-result-observation"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentified-instant-extension",
    "valueDateTime" : "2005"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "imaging",
      "display" : "Imaging"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "80940-0",
      "display" : "DXA Femur-L Z-score BMD"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "encounter" : {
    "reference" : "Encounter/de-identified-example"
  },
  "effectivePeriod" : {
    "end" : "2005"
  },
  "performer" : [{
    "reference" : "Practitioner/example"
  }],
  "valueQuantity" : {
    "value" : 0.05,
    "unit" : "Z-Score",
    "system" : "http://unitsofmeasure.org",
    "code" : "{Z-Score}"
  }
}

```
