# US Core Encounter Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Encounter Example**

## Example Encounter: US Core Encounter Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

**Narrative**

Resource "example-1" Updated "2017-05-26 11:56:57-0400" 

Profile:US Core Encounter Profile

**status**: finished

**class**: ambulatory (Details: http://terminology.hl7.org/CodeSystem/v3-ActCode code AMB = 'ambulatory', stated as 'ambulatory')

**type**: Office Visit  (ICD-10-CM#Z00.00)

**subject**: [Patient/example](Patient-example.md) " SHAW"

**period**: 2015-11-01 05:00:14-0500 --> 2015-11-01 06:00:14-0500



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "example",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "Encounter Example"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This is an encounter example for the *US Core Encounter Profile*."
    }],
    "lastUpdated" : "2017-05-26T11:56:57.250-04:00",
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter"]
  },
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB",
    "display" : "ambulatory"
  },
  "type" : [{
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10-cm",
      "code" : "Z00.00"
    }],
    "text" : "Encounter for general adult medical examination without abnormal findings."
  }],
  "subject" : {
    "reference" : "Patient/example",
    "display" : "Amy"
  },
  "period" : {
    "start" : "2015-11-01T17:00:14-05:00",
    "end" : "2015-11-01T18:00:14-05:00"
  },
  "hospitalization" : {
    "dischargeDisposition" : {
      "coding" : [{
        "system" : "http://www.nubc.org/patient-discharge",
        "code" : "01",
        "display" : "Discharged to Home"
      }],
      "text" : "Amy was dischaged to home"
    }
  },
  "location" : [{
    "location" : {
      "reference" : "Location/hospital",
      "display" : "Holy Family Hospital"
    }
  }]
}

```
