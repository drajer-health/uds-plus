# Uds Plus Patient Example for a patient with age (> 89 ) - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Patient Example for a patient with age (> 89 )**

## Example Patient: Uds Plus Patient Example for a patient with age (> 89 )

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "de-identified-age89-example",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "De-identified Patient Example"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This is a patient example for the *UDS+ Patient Profile*."
    }],
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/de-identified-uds-plus-patient"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "ombCategory",
      "valueCoding" : {
        "system" : "urn:oid:2.16.840.1.113883.6.238",
        "code" : "2106-3",
        "display" : "White"
      }
    },
    {
      "url" : "detailed",
      "valueCoding" : {
        "system" : "urn:oid:2.16.840.1.113883.6.238",
        "code" : "2108-9",
        "display" : "European"
      }
    },
    {
      "url" : "text",
      "valueString" : "White"
    }],
    "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race"
  },
  {
    "extension" : [{
      "url" : "ombCategory",
      "valueCoding" : {
        "system" : "urn:oid:2.16.840.1.113883.6.238",
        "code" : "2135-2",
        "display" : "Hispanic or Latino"
      }
    },
    {
      "url" : "detailed",
      "valueCoding" : {
        "system" : "urn:oid:2.16.840.1.113883.6.238",
        "code" : "2184-0",
        "display" : "Dominican"
      }
    },
    {
      "url" : "text",
      "valueString" : "Hispanic or Latino"
    }],
    "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity"
  },
  {
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-birthsex-extension",
    "valueCode" : "F"
  },
  {
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-age-extension",
    "valueQuantity" : {
      "value" : 90,
      "comparator" : ">=",
      "unit" : "yr",
      "system" : "http://unitsofmeasure.org",
      "code" : "a"
    }
  }],
  "active" : true,
  "gender" : "female",
  "address" : [{
    "postalCode" : "00000-1234",
    "_postalCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
        "valueCode" : "masked"
      }]
    }
  }]
}

```
