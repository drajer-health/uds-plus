# UDS Plus Housing Status Codes - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Housing Status Codes**

## CodeSystem: UDS Plus Housing Status Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-housing-status-codes | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusHousingStatusCodes |

 
The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying Housing status of patients in UDS+ program. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Uds Plus Housing Status Codes](ValueSet-udsplus-housing-status.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "udsplus-housing-status-codes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-housing-status-codes",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusHousingStatusCodes",
  "title" : "UDS Plus Housing Status Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-09-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying Housing status of patients in UDS+ program.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "http://fhir.org/guides/hrsa/uds-plus/ValueSet/udsplus-housing-status",
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "homeless-shelter",
    "display" : "Patients in Homeless Shelters",
    "definition" : "Patients who are living in a homeless shelter"
  },
  {
    "code" : "transitional",
    "display" : "Patients in transitional state",
    "definition" : "Patients who do not have a house and are in a transitional state"
  },
  {
    "code" : "doubling-up",
    "display" : "Patients doubling up",
    "definition" : "Patients who are doubling up with others."
  },
  {
    "code" : "street",
    "display" : "Patients who are on the streets",
    "definition" : "Patients who do not have a house and are living on the streets"
  },
  {
    "code" : "permanent-supportive-housing",
    "display" : "Patients in permanent supportive housing",
    "definition" : "Patients who are living in a permanent supportive housing"
  },
  {
    "code" : "other",
    "display" : "Patients who have other kinds of accomodation",
    "definition" : "Patients who have other kinds of accomodation"
  },
  {
    "code" : "unknown",
    "display" : "Patients with Unknown accomodation",
    "definition" : "Patients with Unknown accomodation"
  }]
}

```
