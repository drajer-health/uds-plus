# Uds Plus ServiceRequest Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus ServiceRequest Example**

## Example ServiceRequest: Uds Plus ServiceRequest Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "ServiceRequest",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-servicerequest"]
  },
  "status" : "completed",
  "intent" : "order",
  "doNotPerform" : false,
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "76164006",
      "display" : "Biopsy of colon (procedure)"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "encounter" : {
    "reference" : "Encounter/de-identified-example"
  },
  "authoredOn" : "2017",
  "requester" : {
    "reference" : "Practitioner/example"
  },
  "bodySite" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "485005",
      "display" : "Transverse colon structure"
    }]
  }]
}

```
