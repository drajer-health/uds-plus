# Uds Plus Low Income Observation Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Low Income Observation Example**

## Example Observation: Uds Plus Low Income Observation Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "de-identified-low-income-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/de-identified-uds-plus-income-observation"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "63058-2"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "effectiveDateTime" : "2016",
  "valueRange" : {
    "high" : {
      "value" : 100
    }
  }
}

```
