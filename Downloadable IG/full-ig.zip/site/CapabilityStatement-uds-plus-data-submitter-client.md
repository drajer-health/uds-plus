# Uds Plus Data Submitter CapabilityStatement - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Data Submitter CapabilityStatement**

## CapabilityStatement: Uds Plus Data Submitter CapabilityStatement 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-submitter-client | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusDataSubmitter |

 
This is a CapabilityStatement that defines the expected capabilities of the Data Submitter actor. 

 [Raw OpenAPI-Swagger Definition file](uds-plus-data-submitter-client.openapi.json) | [Download](uds-plus-data-submitter-client.openapi.json) 

## Data Receiver

(Requirements Definition Capability Statement)

Canonical URL: http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-submitter-client

Published by: **HL7 International - Public Health Work Group** 

This is a CapabilityStatement that defines the expected capabilities of the Data Submitter actor as a client. 

## General

* FHIR Version:: Supported formats:
  * 4.0.1: json

## REST behavior

The primary focus of the Data Submitter actor as a client is to invoke the Group/$export operation identified below and extract the UDS+ data using US Core and QI Core profiles. In certain cases, the Data Submitter MAY have to invoke individual patient api's to extract the necessary UDS+ data when the Data Source does not support Group/$export operation. data. 

 **Security:** 

Implementations must meet the general security requirements documented in FHIR [Security guidance](http://hl7.org/fhir/security.html).

In addition the Data Submitter actor as a client needs to meet the security requirements as outlined in the [SMART on FHIR Backend Services Authorization](spec.md#smart-on-fhir-backend-services-authorization)

### Resource summary


### FHIR Operations summary

As a client, the Data Submitter has to be capable of invoking the below operation on the Data Source.

*  [Bulk Data Export ([BaseURL]/Group/[Id]/$export)](http://hl7.org/fhir/uv/bulkdata/OperationDefinition-group-export.html) 

As a client, the Data Submitter has to be capable of invoking the below operation on the Data Receiver to submit the manifest file.

*  [Bulk Data Import ([BaseURL]/$import)](OperationDefinition-import.md) 

###  UDS+ profiles 

Profiles: All UDS+ profiles 

#### Interactions

*  search:  read
  * Search for specific UDS+ resource profile instances.: Retrieve specific UDS+ resource profile instances



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "uds-plus-data-submitter-client",
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-submitter-client",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusDataSubmitter",
  "title" : "Uds Plus Data Submitter CapabilityStatement",
  "status" : "draft",
  "date" : "2020-12-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "This is a CapabilityStatement that defines the expected capabilities of the Data Submitter actor.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "rest" : [{
    "mode" : "client",
    "documentation" : "The primary focus of the Data Submitter is to invoke the Group/[id]/$export operation and gather the UDS+ data using US Core and QI Core profiles.",
    "security" : {
      "description" : "Implementations must meet the general security requirements documented in the security section of the implementation guide."
    },
    "operation" : [{
      "name" : "export",
      "definition" : "http://hl7.org/fhir/uv/bulkdata/OperationDefinition/group-export"
    },
    {
      "name" : "import",
      "definition" : "http://fhir.org/guides/hrsa/uds-plus/OperationDefinition/import"
    }]
  }]
}

```
