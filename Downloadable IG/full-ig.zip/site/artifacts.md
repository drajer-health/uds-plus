# Artifacts Summary - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [Uds Plus Data Receiver CapabilityStatement](CapabilityStatement-uds-plus-data-receiver-server.md) | This is a CapabilityStatement that defines the expected capabilities of the Data Receiver actor as a Server. |
| [Uds Plus Data Source CapabilityStatement](CapabilityStatement-uds-plus-data-source.md) | This is a CapabilityStatement that defines the expected capabilities of the Data Source actor. |
| [Uds Plus Data Submitter CapabilityStatement](CapabilityStatement-uds-plus-data-submitter-client.md) | This is a CapabilityStatement that defines the expected capabilities of the Data Submitter actor. |

### Behavior: Operation Definitions 

These are custom operations that can be supported by and/or invoked by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [UDS Plus Import](OperationDefinition-import.md) | Notification from a Health Center about the availability of the data to HRSA using Bulk Import mechanism. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [UDS Plus Import Manifest](StructureDefinition-uds-plus-import-manifest.md) | The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Manifest for UDS+ import FHIR Operations. |
| [UDS Plus Patient Reporting Parameters](StructureDefinition-uds-plus-patient-reporting-parameters.md) | The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Patients and if they are counted for the various reports. |
| [UdsPlus De-identified Patient](StructureDefinition-uds-plus-deidentified-patient.md) | This Patient profile represents a UDS+ de-identified patient |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [UDS Plus Agriculture Worker Status Extension](StructureDefinition-udsplus-agriculture-worker-status.md) | Indicates the agriculture worker status of the patient at a specific time |
| [UDS Plus Capitated Member Months Extension](StructureDefinition-uds-plus-capitated-member-months-extension.md) | Indicates the number of capitated member months of the patient for the reporting year |
| [UDS Plus FeeForService Member Months Extension](StructureDefinition-uds-plus-feeforservice-member-months-extension.md) | Indicates the number of FeeForService member months of the patient for the reporting year |
| [UDS Plus Housing Status Extension](StructureDefinition-uds-plus-housing-status-extension.md) | Indicates the housing status of the patient at a specific time |
| [UDS Plus Veteran Status Extension](StructureDefinition-uds-plus-veteran-status-extension.md) | Indicates the Veteran status of the patient. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Uds Plus Agriculture Worker Status Codes](ValueSet-udsplus-agriculture-worker-status.md) | The Uds Plus Agriculture Worker Status Codes is a 'starter set' of codes for specifying agriculture worker status for Patients. |
| [Uds Plus Housing Status Codes](ValueSet-udsplus-housing-status.md) | The Uds Plus Housing Status Codes is a 'starter set' of codes for identifying the Patient's housing status. |
| [Uds Plus Insurance Codes](ValueSet-uds-plus-insurance-codes.md) | The Uds Plus Insurance Codes is a 'starter set' of codes for identifying the source of the insurance for Patients. |
| [Uds Plus Service Delivery Codes](ValueSet-uds-plus-service-delivery-codes.md) | The UDS Plus CodeSystem is an 'addition set' of one code to the existing Location Service Delivery Codes value set for UDS+ purposes. |
| [Uds Plus Sex Codes](ValueSet-uds-plus-sex-codes.md) | The Uds Plus Birth Sex Codes is a set of codes for identifying the birth sex of Patients, This ValueSet will deprecated in the future in favor of the CMS Sex codes value set used as part of the uds-plus-sex-extension. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [UDS Plus Agriculter Worker Status Codes](CodeSystem-udsplus-agriculture-worker-status-codes.md) | The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying agriculture worker status for UDS+ program. |
| [UDS Plus Housing Service Delivery Codes](CodeSystem-udsplus-service-delivery-codes.md) | The UDS Plus CodeSystem is an 'addition set' of one code to the existing Location Service Delivery Codes value set for UDS+ purposes. |
| [UDS Plus Housing Status Codes](CodeSystem-udsplus-housing-status-codes.md) | The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying Housing status of patients in UDS+ program. |
| [UDS Plus Insurance Codes](CodeSystem-uds-plus-insurance-codes.md) | The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying insurance types used by patients in UDS+ program. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Example of a Manifest file used for multiple operations in the context of HRSA UDS+ FHIR IG](Parameters-example.md) | An Example of a conformant UDS+ Parameters resource representing a manifest file used by the $import and the $de-identify operation. |
| [UDS Plus AdverseEvent Example](AdverseEvent-de-identified-example.md) | An Example of a conformant UDS Plus AdverseEvent resource with de-identified information. |
| [UDS Plus AllergyIntolerance Example](AllergyIntolerance-de-identified-example.md) | An Example of a conformant UDS Plus AllergyIntolerance resource with de-identified information. |
| [UDS Plus ClinicalResult Example](Observation-clinical-result-de-identified-example.md) | An Example of a conformant UDS Plus ClincialResult resource profile with de-identified information. |
| [UDS Plus Generic Observation Example](Observation-generic-observation-de-identified-example.md) | An Example of a conformant UDS Plus Observation resource profile with de-identified information. |
| [UDS Plus Parameters Example for $deidentify operation](Parameters-de-identify-data-operation-urls-example.md) | An Example of a conformant UDS Plus Parameters resource for sending input and receiving output from $deidentify operation. |
| [UDS Plus RelatedPerson Example](RelatedPerson-de-identified-example.md) | An Example of a conformant UDS Plus Related Person resource with de-identified information. |
| [UDS Plus Reporting Parameters Example](Parameters-reporting-parameters-example.md) | An Example of a conformant UDS Plus Reporting Parameters resource with de-identifeid information. |
| [US Core Condition Example](Condition-example.md) | An Example of a conformant US Core Condition resource with identifiable information capturing a Problem List Item. |
| [US Core Encounter Example](Encounter-example.md) | An Example of a conformant US Core Encounter resource with identifiable information capturing a visit. |
| [US Core Healthcare Organization Example](Organization-holy-healthcare.md) | An Example of a conformant US Core Healthcare Organization resource with identifiable information. |
| [US Core Location Example](Location-hospital.md) | An Example of a conformant US Core Location resource with identifiable information. |
| [US Core Organization Example for a Payer](Organization-acme-payer.md) | An Example of a conformant US Core Organization resource for a Payor entity. |
| [US Core Patient Example](Patient-example.md) | An Example of a conformant US Core Patient resource with identifiable information. |
| [US Core Patient Example of a patient residing in a zip code with small population (<20000 people)](Patient-smallpop-example.md) | An Example of a conformant US Core Patient resource with identifiable information. |
| [US Core Practitioner Example](Practitioner-example.md) | An Example of a conformant US Core Practitioner resource with identifiable information. |
| [Uds Plus Coverage Example](Coverage-de-identified-example.md) | An Example of a conformant UDS Plus Coverage resource with de-identified information. |
| [Uds Plus De-Identified Condition Example](Condition-de-identified-example.md) | An Example of a conformant UDS+ Condition resource with de-identified information capturing a Problem List Item. |
| [Uds Plus De-Identified Encounter Example](Encounter-de-identified-example.md) | An Example of a conformant UDS+ Encounter resource with de-identified information capturing the visit information. |
| [Uds Plus Immunization Example](Immunization-de-identified-example.md) | An Example of a conformant UDS Plus Immunization resource with de-identified information. |
| [Uds Plus Income Observation Example](Observation-de-identified-income-example.md) | An Example of a conformant UDS Plus Observation resource with de-identified income information. |
| [Uds Plus Income Observation Example using Quantity](Observation-de-identified-income-with-quantity-example.md) | An Example of a conformant UDS Plus Observation resource with de-identified income information showing the usage of Quantity to represent income >= 200%. |
| [Uds Plus Low Income Observation Example](Observation-de-identified-low-income-example.md) | An Example of a conformant UDS Plus Observation resource with de-identified income information to represent income <= 100%. |
| [Uds Plus MedicationRequest Example](MedicationRequest-de-identified-example.md) | An Example of a conformant UDS Plus MedicationRequest resource with de-identified information. |
| [Uds Plus MedicationStatement Example](MedicationStatement-de-identified-example.md) | An Example of a conformant UDS Plus MedicationStatement resource with de-identified information. |
| [Uds Plus Observation Lab Result Example](Observation-de-identified-example.md) | An Example of a conformant UDS Plus Observation resource with de-identified information for a Lab Result. |
| [Uds Plus Patient Example](Patient-de-identified-example.md) | An Example of a conformant UDS+ Patient resource which has been de-identified and is based on the US Core Patient small population example resource. |
| [Uds Plus Patient Example for a patient residing in a zip code with small population (<20000 people)](Patient-de-identified-smallpop-example.md) | An Example of a conformant UDS+ Patient resource which has been de-identified and is based on the US Core Patient example resource. |
| [Uds Plus Patient Example for a patient with age (> 89 )](Patient-de-identified-age89-example.md) | An Example of a conformant UDS+ Patient resource which has been de-identified and is based on the US Core Patient example resource. |
| [Uds Plus Procedure Example](Procedure-de-identified-example.md) | An Example of a conformant UDS Plus Procedure resource with de-identified information. |
| [Uds Plus ServiceRequest Example](ServiceRequest-de-identified-example.md) | An Example of a conformant UDS Plus ServiceRequest resource with de-identified information. |

