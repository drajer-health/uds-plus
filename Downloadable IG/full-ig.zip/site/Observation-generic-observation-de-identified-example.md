# UDS Plus Generic Observation Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Generic Observation Example**

## Example Observation: UDS Plus Generic Observation Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "generic-observation-de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-observation"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentified-instant-extension",
    "valueDateTime" : "2005"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "social-history",
      "display" : "Social History"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "160695008",
      "display" : "Transport too expensive"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "effectiveDateTime" : "2021",
  "valueBoolean" : true
}

```
