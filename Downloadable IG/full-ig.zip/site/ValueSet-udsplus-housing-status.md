# Uds Plus Housing Status Codes - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Housing Status Codes**

## ValueSet: Uds Plus Housing Status Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/ValueSet/udsplus-housing-status | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusHousingStatusCodes |

 
The Uds Plus Housing Status Codes is a 'starter set' of codes for identifying the Patient's housing status. 

 **References** 

* [UDS Plus Housing Status Extension](StructureDefinition-uds-plus-housing-status-extension.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "udsplus-housing-status",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2022-08-04T15:52:33.158+00:00",
    "source" : "#3Te0anOrvocKgcow",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/ValueSet/udsplus-housing-status",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusHousingStatusCodes",
  "title" : "Uds Plus Housing Status Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-09-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The Uds Plus Housing Status Codes is a 'starter set' of codes for identifying the Patient's housing status.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-housing-status-codes"
    }]
  }
}

```
