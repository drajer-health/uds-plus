# Uds Plus Coverage Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Coverage Example**

## Example Coverage: Uds Plus Coverage Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Coverage",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-coverage"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-capitated-member-months-extension",
    "valueQuantity" : {
      "value" : 36,
      "unit" : "yr",
      "system" : "http://unitsofmeasure.org",
      "code" : "a"
    }
  },
  {
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-feeforservice-member-months-extension",
    "valueQuantity" : {
      "value" : 36,
      "unit" : "yr",
      "system" : "http://unitsofmeasure.org",
      "code" : "a"
    }
  }],
  "status" : "active",
  "type" : {
    "coding" : [{
      "system" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/uds-plus-insurance-codes",
      "code" : "private-insurance",
      "display" : "Private Insurance"
    }]
  },
  "beneficiary" : {
    "reference" : "Patient/de-identified-example"
  },
  "period" : {
    "start" : "2019",
    "end" : "2023"
  },
  "payor" : [{
    "reference" : "Organization/acme-payer"
  }]
}

```
