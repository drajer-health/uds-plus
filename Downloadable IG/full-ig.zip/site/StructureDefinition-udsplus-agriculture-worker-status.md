# UDS Plus Agriculture Worker Status Extension - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Agriculture Worker Status Extension**

## Extension: UDS Plus Agriculture Worker Status Extension 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/udsplus-agriculture-worker-status | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusAgricultureWorkerStatus |

Indicates the agriculture worker status of the patient at a specific time

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [UdsPlus De-identified Patient](StructureDefinition-uds-plus-deidentified-patient.md)
* Examples for this Extension: [Patient/de-identified-example](Patient-de-identified-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir.hrsa.uds-plus|current/StructureDefinition/StructureDefinition-udsplus-agriculture-worker-status.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-udsplus-agriculture-worker-status.csv), [Excel](StructureDefinition-udsplus-agriculture-worker-status.xlsx), [Schematron](StructureDefinition-udsplus-agriculture-worker-status.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "udsplus-agriculture-worker-status",
  "meta" : {
    "versionId" : "2",
    "lastUpdated" : "2022-07-12T02:03:21.911+00:00",
    "source" : "#IqyJCmUTqk2pvKFb"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/udsplus-agriculture-worker-status",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusAgricultureWorkerStatus",
  "title" : "UDS Plus Agriculture Worker Status Extension",
  "status" : "active",
  "experimental" : false,
  "date" : "2019-09-01",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "Indicates the agriculture worker status of the patient at a specific time",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Patient"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Indicates the agriculture worker status of the patient.",
      "definition" : "Indicates the agriculture worker status of the patient.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "type" : [{
        "code" : "uri"
      }],
      "fixedUri" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/udsplus-agriculture-worker-status"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.org/guides/hrsa/uds-plus/ValueSet/udsplus-agriculture-worker-status"
      }
    }]
  }
}

```
