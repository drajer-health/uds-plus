# Uds Plus Immunization Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Immunization Example**

## Example Immunization: Uds Plus Immunization Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Immunization",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-immunization"]
  },
  "status" : "completed",
  "statusReason" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "encounter-diagnosis",
      "display" : "Encounter Diagnosis"
    }]
  },
  "vaccineCode" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/cvx",
      "code" : "197",
      "display" : "influenza, high-dose, quadrivalent"
    }]
  },
  "patient" : {
    "reference" : "Patient/de-identified-example"
  },
  "occurrenceDateTime" : "2023",
  "recorded" : "2023",
  "primarySource" : true
}

```
