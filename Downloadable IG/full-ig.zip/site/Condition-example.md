# US Core Condition Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Condition Example**

## Example Condition: US Core Condition Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

Profile: [US Core Condition Problems and Health Concerns Profile](http://hl7.org/fhir/us/core/STU8.0.1/StructureDefinition-us-core-condition-problems-health-concerns.html)

**Condition Asserted Date**: 2007-12-14

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**category**: Problem List Items

**code**: Chronic viral hepatitis C

**subject**: [Amy Shaw](Patient-example.md)

**onset**: 2007-12-14

**recordedDate**: 2007-12-14 07:15:07-0800

**note**: 

> 

Amy Shaw has Hepatitis




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "example",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "Diagnosis Example"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This example of a US Core Condition Problems and Health Concerns Profile illustrates its use to capture information about a patient's diagnosis."
    }],
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-condition-problems-health-concerns"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
    "valueDateTime" : "2007-12-14"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active",
      "display" : "Active"
    }],
    "text" : "Active"
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "confirmed",
      "display" : "Confirmed"
    }],
    "text" : "Confirmed"
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "problem-list-item",
      "display" : "Problem List Item"
    }],
    "text" : "Problem List Items"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10-cm",
      "code" : "B18.2",
      "display" : "Chronic viral hepatitis C"
    }],
    "text" : "Chronic viral hepatitis C"
  },
  "subject" : {
    "reference" : "Patient/example",
    "display" : "Amy Shaw"
  },
  "onsetDateTime" : "2007-12-14",
  "recordedDate" : "2007-12-14T07:15:07-08:00",
  "note" : [{
    "text" : "Amy Shaw has Hepatitis"
  }]
}

```
