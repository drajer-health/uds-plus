# Uds Plus De-Identified Condition Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus De-Identified Condition Example**

## Example Condition: Uds Plus De-Identified Condition Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "de-identified-example",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "De-identified Diagnosis Example"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This example of a UDS+ Diagnosis profile which illustrates its use to capture de-identified information about a patient's diagnosis."
    }],
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-diagnosis"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
    "valueDateTime" : "2007"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active",
      "display" : "Active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "confirmed",
      "display" : "Confirmed"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "problem-list-item",
      "display" : "Problem List Item"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10-cm",
      "code" : "B18.2",
      "display" : "Chronic viral hepatitis C"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "onsetDateTime" : "2007",
  "recordedDate" : "2007"
}

```
