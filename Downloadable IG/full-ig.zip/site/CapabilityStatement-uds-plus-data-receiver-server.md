# Uds Plus Data Receiver CapabilityStatement - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Data Receiver CapabilityStatement**

## CapabilityStatement: Uds Plus Data Receiver CapabilityStatement 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-receiver-server | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusDataReceiverServer |

 
This is a CapabilityStatement that defines the expected capabilities of the Data Receiver actor as a Server. 

 [Raw OpenAPI-Swagger Definition file](uds-plus-data-receiver-server.openapi.json) | [Download](uds-plus-data-receiver-server.openapi.json) 

## Data Receiver

(Requirements Definition Capability Statement)

Canonical URL: http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-receiver-server

Published by: **HL7 International - Public Health Work Group** 

This is a CapabilityStatement that defines the expected capabilities of the Data Receiver Server actor. 

## General

* FHIR Version:: Supported formats:
  * 4.0.1: json

## REST behavior

The primary focus of the Data Receiver as a Server is to receive the manifest which contains the links to the UDS+ data that has been extracted by the health center and is being made available to HRSA. 

 **Security:** 

Implementations must meet the general security requirements documented in FHIR [Security guidance](http://hl7.org/fhir/security.html).

In addition the Data Receiver actor needs to meet the security requirements as outlined in the [SMART on FHIR Backend Services Authorization](spec.md#smart-on-fhir-backend-services-authorization)

### FHIR Operations summary

The following FHIR operations SHALL be supported by the Data Source.

*  [UDS+ Import Operation](OperationDefinition-import.md) 
*  [Status Polling using Content-Location received for Bulk Data Import as part of the Content-Location HTTP Header](https://hl7.org/fhir/uv/bulkdata/export.html#bulk-data-status-request) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "uds-plus-data-receiver-server",
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CapabilityStatement/uds-plus-data-receiver-server",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusDataReceiverServer",
  "title" : "Uds Plus Data Receiver CapabilityStatement",
  "status" : "draft",
  "date" : "2020-12-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "This is a CapabilityStatement that defines the expected capabilities of the Data Receiver actor as a Server.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "rest" : [{
    "mode" : "server",
    "documentation" : "The primary focus of the Data Receiver as a Server is to receive the notification manifest which contains the links to the UDS+ data that has        been extracted by the health center and is being made available to HRSA.",
    "security" : {
      "description" : "Implementations must meet the general security requirements documented in the security section of the implementation guide."
    },
    "operation" : [{
      "name" : "import",
      "definition" : "http://fhir.org/guides/hrsa/uds-plus/OperationDefinition/import"
    }]
  }]
}

```
