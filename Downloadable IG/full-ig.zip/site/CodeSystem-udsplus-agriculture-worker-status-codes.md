# UDS Plus Agriculter Worker Status Codes - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Agriculter Worker Status Codes**

## CodeSystem: UDS Plus Agriculter Worker Status Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-agriculture-worker-status-codes | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusAgricultureWorkerStatusCodes |

 
The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying agriculture worker status for UDS+ program. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Uds Plus Agriculture Worker Status Codes](ValueSet-udsplus-agriculture-worker-status.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "udsplus-agriculture-worker-status-codes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-agriculture-worker-status-codes",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusAgricultureWorkerStatusCodes",
  "title" : "UDS Plus Agriculter Worker Status Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-09-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS Plus CodeSystem is a 'starter set' of codes supported for identifying agriculture worker status for UDS+ program.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "http://fhir.org/guides/hrsa/uds-plus/ValueSet/udsplus-agriculture-worker-status",
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "migratory",
    "display" : "Migratory Agriculture Worker",
    "definition" : "Patients whose principal employment is in agriculture and who establish a temporary home for the purposes of such employment as a migratory agricultural worker,"
  },
  {
    "code" : "seasonal",
    "display" : "Seasonal Agriculture Worker",
    "definition" : "Patients whose principal employment is in agriculture on a seasonal basis (e.g., picking fruit during the limited months of a picking season), but who DO NOT establish a temporary home for purposes of such employment"
  }]
}

```
