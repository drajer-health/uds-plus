# US Core Healthcare Organization Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Healthcare Organization Example**

## Example Organization: US Core Healthcare Organization Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

**Organization** 

Resource Organization "acme-payer" 

**identifier**: id: 55555

**active**: true

**type**: Payer  ([Organization type](http://terminology.hl7.org/5.0.0/CodeSystem-organization-type.html)#pay)

**name**: Acme Health Plan

**telecom**: ph: (+1) 555-555-5555, [hq@acme.org](mailto:hq@acme.org)

**address**: 100 Insurance Avenue Amherst MA 01002 USA 



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "holy-healthcare",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization"]
  },
  "identifier" : [{
    "system" : "urn:oid:2.16.840.1.113883.6.300",
    "value" : "55555"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "pay"
    }],
    "text" : "Payer"
  }],
  "name" : "Holy Healthcare",
  "telecom" : [{
    "system" : "phone",
    "value" : "(+1) 555-444-5555"
  },
  {
    "system" : "email",
    "value" : "hq@holyhealthcare.org"
  }],
  "address" : [{
    "line" : ["100 Holy Healthcare Avenue"],
    "city" : "Amherst",
    "state" : "MA",
    "postalCode" : "01002",
    "country" : "USA"
  }]
}

```
