# UdsPlus De-identified Patient - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UdsPlus De-identified Patient**

## Resource Profile: UdsPlus De-identified Patient 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentified-patient | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UdsPlusDeIdentifiedPatient |

 
This Patient profile represents a UDS+ de-identified patient 

**Usages:**

* This Profile is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir.hrsa.uds-plus|current/StructureDefinition/StructureDefinition-uds-plus-deidentified-patient.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-uds-plus-deidentified-patient.csv), [Excel](StructureDefinition-uds-plus-deidentified-patient.xlsx), [Schematron](StructureDefinition-uds-plus-deidentified-patient.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "uds-plus-deidentified-patient",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2026-03-27T02:03:11.293+00:00"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-deidentified-patient",
  "version" : "3.0.0-draft",
  "name" : "UdsPlusDeIdentifiedPatient",
  "title" : "UdsPlus De-identified Patient",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-13T10:51:25+00:00",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "This Patient profile represents a UDS+ de-identified patient",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/us/dapl/StructureDefinition/dapl-deidentified-patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient",
      "path" : "Patient",
      "short" : "Uds Plus Deidentified Patient",
      "definition" : "The profile establishes the core elements, extensions, vocabularies and value sets for representing de-identified patients for the Uds Plus use cases."
    },
    {
      "id" : "Patient.extension:uds-plus-agriculture-worker-status",
      "path" : "Patient.extension",
      "sliceName" : "uds-plus-agriculture-worker-status",
      "short" : "Agriculture Status of the patient",
      "definition" : "Indicates the agriculture worker status of the patient.",
      "min" : 0,
      "max" : "1",
      "base" : {
        "path" : "DomainResource.extension",
        "min" : 0,
        "max" : "*"
      },
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/udsplus-agriculture-worker-status"]
      }],
      "mustSupport" : true,
      "isModifier" : false
    },
    {
      "id" : "Patient.extension:uds-plus-housing-status",
      "path" : "Patient.extension",
      "sliceName" : "uds-plus-housing-status",
      "short" : "Housing Status of the patient",
      "definition" : "Indicates the housing status of the Patient at a specific time",
      "min" : 0,
      "max" : "1",
      "base" : {
        "path" : "DomainResource.extension",
        "min" : 0,
        "max" : "*"
      },
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-housing-status-extension"]
      }],
      "mustSupport" : true,
      "isModifier" : false
    },
    {
      "id" : "Patient.extension:uds-plus-veteran-status",
      "path" : "Patient.extension",
      "sliceName" : "uds-plus-veteran-status",
      "short" : "Veteran Status of the patient",
      "definition" : "Indicates the Veteran status of the Patient, populate with true when the patient is a veteran",
      "min" : 0,
      "max" : "1",
      "base" : {
        "path" : "DomainResource.extension",
        "min" : 0,
        "max" : "*"
      },
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-veteran-status-extension"]
      }],
      "mustSupport" : true,
      "isModifier" : false
    }]
  }
}

```
