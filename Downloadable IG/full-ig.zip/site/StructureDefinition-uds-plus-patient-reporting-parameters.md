# UDS Plus Patient Reporting Parameters - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Patient Reporting Parameters**

## Resource Profile: UDS Plus Patient Reporting Parameters 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-patient-reporting-parameters | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusPatientReportingParameters |

 
The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Patients and if they are counted for the various reports. 

### Introduction

This profile is used to represent the applicability of the patient data for each report. In other words, the reporting parameters profile is used to convey if a patient should be considered as part of a specific report. One instance of this is expected to be created for each patient that is part of the patient.ndjson file.

**Funding Streams**

Since the patient data may be applicable to multiple funding streams, an attribute called "combinedFundingStreams" has been added to the Reporting Parameters profile. This string is expected to contain the various funding streams to which this patient is applicable. The attribute will contain a comma separated list of all the funding streams. For e.g a Patient who is part of the CHC and MHC funding streams will contain the string "CHC,MHC" in the combindedFundingStreams data element. The list of funding streams allowed are

* CHC - Community Health Center
* MHC - Migrant Health Center
* HCH - Healthcare for the Homeless
* PHPC - Public Housing Primary Care

**Report Names**

The reportNames attribute contains the information that links the patient to the different UDS Plus reports.

For e.g A Patient who is part of "table6B-Line11-Cervical-Cancer-Screening-CMS124" quality measure will have the valueBoolean set to true for the corresponding line item. For the same patient if the data does not apply to "table6B-Line11a-Breast-Cancer-Screening-CMS125" report, then the valueBoolean will be set to false. This is applicable to all measures and tables specified in the UDS Manual.

**eCQM/Quality Measure Flags in Reporting Parameters**

The Reporting Parameters profile below is used to indicate which Patients have to be considered for the measure calculations. For CMS 117 this is performed as follows:

In the Parameters resource the CMS 117 is identified by the Parameter.part.name = "table6B-Line10-Childhood-Immunization-Status-CMS117".

For the same part element (table6B-Line10-Childhood-Immunization-Status-CMS117) if the Parameter.part.value[x] is true, then the Patient referenced in the value[x] for the part Paremeter.part.name = "patientReference" is considered for the computation of the measure. In other words a true indicates that the patient has met the Initial Patient Population criteria. A value of false for the measure indicates that the Patient's data would not be used in the computation of the measure.

In the initial stages of UDS+ adoption, it is extremely valuable for both Health Centers and HRSA to determine if the counts calculated by the Health Center are same as the counts calculated by HRSA for the same measure. In order to facilitate this cross-verification process, the Reporting Parameters resource has been enhanced so that vendors can indicate if a Patient is part of the numerator, denominator etc. This is an optional capability which vendors can leverage to supply the additional detail to aid in cross-verification.

The new capability allows the Health Centers to identify if the patient is part of:

* Denominator (den), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-den in the name field.
* Denominator Exceptions (denexp), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-denexp in the name field.
* Denominator Exclusions (denexcl), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-denexcl in the name field.
* Numerator (num), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-num in the name field.
* Numerator Excpetions (numexcp), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-numexp in the name field.
* Numerator Exclusions (numexcl), An example for CMS 117 is designated as table6B-Line10-Childhood-Immunization-Status-CMS117-numexcl in the name field.

**Partial Submission Option**

For partial submission requirements, please refer to the [Partial Submission Requirements](spec.md#data-submitter-requirements)

**Usages:**

* Examples for this Profile: [Parameters/reporting-parameters-example](Parameters-reporting-parameters-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir.hrsa.uds-plus|current/StructureDefinition/StructureDefinition-uds-plus-patient-reporting-parameters.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-uds-plus-patient-reporting-parameters.csv), [Excel](StructureDefinition-uds-plus-patient-reporting-parameters.xlsx), [Schematron](StructureDefinition-uds-plus-patient-reporting-parameters.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "uds-plus-patient-reporting-parameters",
  "meta" : {
    "versionId" : "12",
    "lastUpdated" : "2022-07-12T02:03:11.293+00:00",
    "source" : "#3LDMUQYYwafwTzqK"
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-patient-reporting-parameters",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusPatientReportingParameters",
  "title" : "UDS Plus Patient Reporting Parameters",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-13T10:51:25+00:00",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Patients and if they are counted for the various reports.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Parameters",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Parameters",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Parameters",
      "path" : "Parameters",
      "short" : "UDS Plus Patient Reporting Parameters",
      "definition" : "The UDS+ profile is based on the **Parameters FHIR Resource and establishes the core elements, extensions, vocabularies and value sets for representing the Patients and if they are counted for the various reports."
    },
    {
      "id" : "Parameters.parameter",
      "path" : "Parameters.parameter",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 2,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:patientReference",
      "path" : "Parameters.parameter",
      "sliceName" : "patientReference",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:patientReference.name",
      "path" : "Parameters.parameter.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "patientReference",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:patientReference.valueReference",
      "path" : "Parameters.parameter.valueReference",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/us/dapl/StructureDefinition/dapl-deidentified-patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:patientReference.valueReference.display",
      "path" : "Parameters.parameter.valueReference.display",
      "min" : 0,
      "max" : "0",
      "mustSupport" : false
    },
    {
      "id" : "Parameters.parameter:combinedFundingStreams",
      "path" : "Parameters.parameter",
      "sliceName" : "combinedFundingStreams",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:combinedFundingStreams.name",
      "path" : "Parameters.parameter.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "combinedFundingStreams",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:combinedFundingStreams.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames",
      "path" : "Parameters.parameter",
      "sliceName" : "reportNames",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.name",
      "path" : "Parameters.parameter.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "reportNames",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part",
      "path" : "Parameters.parameter.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:patientsByZip",
      "path" : "Parameters.parameter.part",
      "sliceName" : "patientsByZip",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:patientsByZip.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "patientsByZip",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:patientsByZip.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3A",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table3A",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3A.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table3A",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3A.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3B",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table3B",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3B.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table3B",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table3B.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table4",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table4",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table4.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table4",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table4.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6A",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6A",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6A.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6A",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6A.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line1-6",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line1-6",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line1-6.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line1-6-Age-Of-Prenatal-Care-Patients",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line1-6.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line7-9",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line7-9",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line7-9.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line7-9-Early-Entry-Into-Prenatal-Care",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line7-9.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line10",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line10-Childhood-Immunization-Status-CMS117",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line10-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line10-Childhood-Immunization-Status-CMS117-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line10-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line10-Childhood-Immunization-Status-CMS117-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line10-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line10-Childhood-Immunization-Status-CMS117-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line10.part:table6B-Line10-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line11",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11-Cervical-Cancer-Screening-CMS124",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11-Cervical-Cancer-Screening-CMS124-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11-Cervical-Cancer-Screening-CMS124-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11-Cervical-Cancer-Screening-CMS124-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11.part:table6B-Line11-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line11a",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11a-Breast-Cancer-Screening-CMS125",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11a-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11a-Breast-Cancer-Screening-CMS125-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11a-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11a-Breast-Cancer-Screening-CMS125-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line11a-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line11a-Breast-Cancer-Screening-CMS125-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line11a.part:table6B-Line11a-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line12",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line12-Weight-Assessment-And-Counselling-CMS155",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line12-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line12-Weight-Assessment-And-Counselling-CMS155-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line12-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line12-Weight-Assessment-And-Counselling-CMS155-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line12-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line12-Weight-Assessment-And-Counselling-CMS155-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line12.part:table6B-Line12-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line13",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line13-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line13-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexp",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line13-denexp",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexp.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69-denexp",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-denexp.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line13-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line13-Preventive-Care-And-Screening-BMI-CMS69-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line13.part:table6B-Line13-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line14a",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line14a-Preventive-Care-And-Screening-Tobacco-Use-CMS138",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line14a-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line14a-Preventive-Care-And-Screening-Tobacco-Use-CMS138-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line14a-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line14a-Preventive-Care-And-Screening-Tobacco-Use-CMS138-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line14a-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line14a-Preventive-Care-And-Screening-Tobacco-Use-CMS138-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line14a.part:table6B-Line14a-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line17a",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line17a-Statin-Therapy-CMS347",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line17a-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line17a-Statin-Therapy-CMS347-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line17a-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line17a-Statin-Therapy-CMS347-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexp",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line17a-denexp",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexp.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line17a-Statin-Therapy-CMS347-denexp",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-denexp.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line17a-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line17a-Statin-Therapy-CMS347-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line17a.part:table6B-Line17a-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line18",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line18-Ischmic-Vascular-Disease-CMS164",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line18-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line18-Ischmic-Vascular-Disease-CMS164-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line18-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line18-Ischmic-Vascular-Disease-CMS164-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line18-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line18-Ischmic-Vascular-Disease-CMS164-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line18.part:table6B-Line18-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line19",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line19-Colorectal-Cancer-Screening-CMS130",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line19-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line19-Colorectal-Cancer-Screening-CMS130-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line19-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line19-Colorectal-Cancer-Screening-CMS130-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line19-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line19-Colorectal-Cancer-Screening-CMS130-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line19.part:table6B-Line19-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line20",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20-HIV-Linkage-To-Care",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20-HIV-Linkage-To-Care-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20-HIV-Linkage-To-Care-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20-HIV-Linkage-To-Care-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20.part:table6B-Line20-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line20a",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20a-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20a-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line20a-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line20a.part:table6B-Line20a-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line21",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line21-Preventive-Care-And-Screening-For-Depression-CMS2",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part",
      "path" : "Parameters.parameter.part.part",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.name"
        }],
        "rules" : "open"
      },
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-den",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line21-den",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-den.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-den",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-den.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-denexcl",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line21-denexcl",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-denexcl.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-denexcl",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-denexcl.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-num",
      "path" : "Parameters.parameter.part.part",
      "sliceName" : "table6B-Line21-num",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-num.name",
      "path" : "Parameters.parameter.part.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line20a-HIV-Screening-CMS349-num",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21.part:table6B-Line21-num.value[x]",
      "path" : "Parameters.parameter.part.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21a",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line21a",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21a.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line21a-Depression-Remission-At-Twelve-Months-CMS159",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line21a.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line22",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table6B-Line22",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line22.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table6B-Line22-Dental-Sealants-For-Children-CMS277",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table6B-Line22.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line0",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table7-Line0",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line0.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table7-Line0-HIV-Positive-Pregnant-Patients",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line0.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table7-Line2",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table7-Line2-Deliveries-Performed-By-Health-Center",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line1a-d",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table7-Line1a-d",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line1a-d.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table7-Line1a-d-Prenatal-Care-Patient-Deliveries",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line1a-d.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2a-c",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table7-Line2a-c",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2a-c.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table7-Line2a-c-Controlling-High-Blood-Pressure-CMS165",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line2a-c.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line3a-f",
      "path" : "Parameters.parameter.part",
      "sliceName" : "table7-Line3a-f",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line3a-f.name",
      "path" : "Parameters.parameter.part.name",
      "min" : 1,
      "max" : "1",
      "fixedString" : "table7-Line3a-f-HbA1c-Poor-Control-CMS122",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:reportNames.part:table7-Line3a-f.value[x]",
      "path" : "Parameters.parameter.part.value[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    }]
  }
}

```
