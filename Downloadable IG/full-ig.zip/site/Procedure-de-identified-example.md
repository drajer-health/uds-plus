# Uds Plus Procedure Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus Procedure Example**

## Example Procedure: Uds Plus Procedure Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "Procedure",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-procedure"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-recordedDate-extension",
    "valueDateTime" : "2005"
  }],
  "status" : "completed",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "48387007",
      "display" : "Tracheotomy"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "encounter" : {
    "reference" : "Encounter/de-identified-example"
  },
  "performedDateTime" : "2005",
  "performer" : [{
    "actor" : {
      "reference" : "Practitioner/example"
    }
  }],
  "bodySite" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "44567001",
      "display" : "Tracheal structure"
    }]
  }]
}

```
