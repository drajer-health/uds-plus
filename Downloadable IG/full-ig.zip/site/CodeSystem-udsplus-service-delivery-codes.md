# UDS Plus Housing Service Delivery Codes - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UDS Plus Housing Service Delivery Codes**

## CodeSystem: UDS Plus Housing Service Delivery Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-service-delivery-codes | *Version*:3.0.0-draft | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:UDSPlusServiceDeliveryCodes |

 
The UDS Plus CodeSystem is an 'addition set' of one code to the existing Location Service Delivery Codes value set for UDS+ purposes. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Uds Plus Service Delivery Codes](ValueSet-uds-plus-service-delivery-codes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "udsplus-service-delivery-codes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.org/guides/hrsa/uds-plus/ImplementationGuide/fhir.hrsa.uds-plus"
      }]
    }
  }],
  "url" : "http://fhir.org/guides/hrsa/uds-plus/CodeSystem/udsplus-service-delivery-codes",
  "version" : "3.0.0-draft",
  "name" : "UDSPlusServiceDeliveryCodes",
  "title" : "UDS Plus Housing Service Delivery Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-09-06",
  "publisher" : "HRSA BPHC",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://bphc.hrsa.gov/"
    }]
  }],
  "description" : "The UDS Plus CodeSystem is an 'addition set' of one code to the existing Location Service Delivery Codes value set for UDS+ purposes.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "public-housing",
    "display" : "Care was delivered in a Location that is considered public housing",
    "definition" : "Care was delivered in a Location that is considered public housing"
  },
  {
    "code" : "school",
    "display" : "Care was delivered in a Location that is considered a school",
    "definition" : "Care was delivered in a Location that is considered a school"
  }]
}

```
