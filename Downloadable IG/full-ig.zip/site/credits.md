# Credits - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* **Credits**

## Credits

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

### Credits

Primary authors:

* Nagesh Bashyam (Drajer LLC)

Project lead:

* ONC - Leliveld.Emeni
* ONC - Matthew Rahn
* HRSA - Health Resources & Services Administration

Project participants included:

* Rachel Fried - Leap Orbit
* Michael Hunter - Leap Orbit
* HRSA UDS UTC
* Vendors Providing Feedback (Azara, Athena, eCW, Epic, Nextgen, Relevant, i2i)

Our thanks to these and to the many others not explicitly listed who contributed their time, enthusiasm and expertise to this work.

