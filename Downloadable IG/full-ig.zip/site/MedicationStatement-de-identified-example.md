# Uds Plus MedicationStatement Example - HRSA 2026 Uniform Data System (UDS) Patient Level Submission (PLS) (UDS+) FHIR IG v3.0.0-draft

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Uds Plus MedicationStatement Example**

## Example MedicationStatement: Uds Plus MedicationStatement Example

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |



## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "de-identified-example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/hrsa/uds-plus/StructureDefinition/uds-plus-medicationstatement"]
  },
  "status" : "active",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "476872",
      "display" : "Nizatidine 15 MG/ML Oral Solution"
    }]
  },
  "subject" : {
    "reference" : "Patient/de-identified-example"
  },
  "effectiveDateTime" : "2008",
  "dateAsserted" : "2008",
  "dosage" : [{
    "text" : "10 mL bid",
    "timing" : {
      "repeat" : {
        "boundsPeriod" : {
          "start" : "2008-04-05"
        },
        "frequency" : 2,
        "period" : 1,
        "periodUnit" : "d"
      }
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 10,
        "unit" : "ml",
        "system" : "http://unitsofmeasure.org",
        "code" : "mL"
      }
    }]
  }]
}

```
